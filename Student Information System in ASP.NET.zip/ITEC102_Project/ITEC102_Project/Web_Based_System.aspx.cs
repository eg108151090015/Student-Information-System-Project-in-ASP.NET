﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace ITEC102_Project
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetDepartment();
                GetRegion();
                GetProvince();
            }
            record.Visible = false;

            clear.Enabled = false;

            confirm();
        }

        private void GetDepartment()
        {
            DataTable departmentdt = new DataTable();

            departmentdt.Columns.Add("Department ID", typeof(int));
            departmentdt.Columns.Add("DepartmentName");

            departmentdt.Rows.Add(1, "Select");
            departmentdt.Rows.Add(2, "School of Business Management");
            departmentdt.Rows.Add(3, "School of Computer Studies");
            departmentdt.Rows.Add(4, "School of Education");
            departmentdt.Rows.Add(5, "School of Hospitality and Tourism Management");

            department.DataSource = departmentdt;
            department.DataTextField = "DepartmentName";
            department.DataValueField = "Department ID";
            department.DataBind();
        }

        private void GetRegion()
        {
            DataTable regiondt = new DataTable();

            regiondt.Columns.Add("Region ID", typeof(int));
            regiondt.Columns.Add("RegionName");

            regiondt.Rows.Add(1, "Select");
            regiondt.Rows.Add(2, "Region I – Ilocos Region");
            regiondt.Rows.Add(3, "Region II – Cagayan Valley");
            regiondt.Rows.Add(4, "Region III – Central Luzon");
            regiondt.Rows.Add(5, "Region IV‑A – CALABARZON");
            regiondt.Rows.Add(6, "Region IV‑B – MIMAROPA Region");
            regiondt.Rows.Add(7, "Region V – Bicol Region");
            regiondt.Rows.Add(8, "Region VI – Western Visayas");
            regiondt.Rows.Add(9, "Region VII – Central Visayas");
            regiondt.Rows.Add(10, "Region VIII – Eastern Visayas");
            regiondt.Rows.Add(11, "Region IX – Zamboanga Peninsula");
            regiondt.Rows.Add(12, "Region X – Northern Mindanao");
            regiondt.Rows.Add(13, "Region XI – Davao Region");
            regiondt.Rows.Add(14, "Region XII – SOCCSKSARGEN");
            regiondt.Rows.Add(15, "Region XIII – Caraga");
            regiondt.Rows.Add(16, "NCR – National Capital Region");
            regiondt.Rows.Add(17, "CAR – Cordillera Administrative Region");
            regiondt.Rows.Add(18, "BARMM – Bangsamoro Autonomous Region in Muslim Mindanao");

            region.DataSource = regiondt;
            region.DataTextField = "RegionName";
            region.DataValueField = "Region ID";
            region.DataBind();
        }

        private void GetProvince()
        {
            DataTable provincedt = new DataTable();

            provincedt.Columns.Add("Province ID", typeof(int));
            provincedt.Columns.Add("ProvinceName");

            provincedt.Rows.Add(1, "Select");

            province.DataSource = provincedt;
            province.DataTextField = "ProvinceName";
            province.DataValueField = "Province ID";
            province.DataBind();
        }

        protected void department_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable coursedt = new DataTable();

            if (int.Parse(department.SelectedValue) > 0)
            {
                coursedt.Columns.Add("Department ID", typeof(int));
                coursedt.Columns.Add("Course ID", typeof(int));
                coursedt.Columns.Add("CourseName");

                if(department.SelectedValue == "1")
                {
                    coursedt.Rows.Add(1, 1, "Select");
                }
                else if (department.SelectedValue == "2")
                {
                    coursedt.Rows.Add(2, 1, "Select");
                    coursedt.Rows.Add(2, 2, "BSBA Marketing Management");
                    coursedt.Rows.Add(2, 3, "BSBA Human Resource Development Management");
                    coursedt.Rows.Add(2, 4, "BS Office Administration");
                }
                else if (department.SelectedValue == "3")
                {
                    coursedt.Rows.Add(3, 1, "Select");
                    coursedt.Rows.Add(3, 2, "BS Information Technology");
                    coursedt.Rows.Add(3, 3, "BS Computer Science");
                }
                else if (department.SelectedValue == "4")
                {
                    coursedt.Rows.Add(4, 1, "Select");
                    coursedt.Rows.Add(4, 2, "BSE English");
                    coursedt.Rows.Add(4, 3, "BSE Social Studies");
                    coursedt.Rows.Add(4, 4, "BSE Filipino");
                    coursedt.Rows.Add(4, 5, "BSE Mathematics");
                }
                else if (department.SelectedValue == "5")
                {
                    coursedt.Rows.Add(5, 1, "Select");
                    coursedt.Rows.Add(5, 2, "BS Hospitality Management");
                    coursedt.Rows.Add(5, 3, "BS Tourism Management");
                }

                course.DataSource = coursedt;
                course.DataTextField = "CourseName";
                course.DataValueField = "Course ID";
                course.DataBind();
            }
        }

        protected void region_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable provincedt = new DataTable();

            DataTable citydt = new DataTable(); 

            if (int.Parse(region.SelectedValue) > 0)
            {
                provincedt.Columns.Add("Region ID", typeof(int));
                provincedt.Columns.Add("Province ID", typeof(int));
                provincedt.Columns.Add("ProvinceName");

                citydt.Columns.Add("Province ID", typeof(int));
                citydt.Columns.Add("City ID", typeof(int));
                citydt.Columns.Add("CityName");

                if (region.SelectedValue == "1")
                {
                    provincedt.Rows.Add(1, 1, "Select");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "2")
                {
                    provincedt.Rows.Add(2, 1, "Select");
                    provincedt.Rows.Add(2, 2, "Ilocos Norte");
                    provincedt.Rows.Add(2, 3, "Ilocos Sur");
                    provincedt.Rows.Add(2, 4, "La Union");
                    provincedt.Rows.Add(2, 5, "Pangasinan");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "3")
                {
                    provincedt.Rows.Add(3, 1, "Select");
                    provincedt.Rows.Add(3, 2, "Batanes");
                    provincedt.Rows.Add(3, 3, "Cagayan");
                    provincedt.Rows.Add(3, 4, "Isabela");
                    provincedt.Rows.Add(3, 5, "Nueva Vizcaya");
                    provincedt.Rows.Add(3, 6, "Quirino");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "4")
                {
                    provincedt.Rows.Add(4, 1, "Select");
                    provincedt.Rows.Add(4, 2, "Aurora");
                    provincedt.Rows.Add(4, 3, "Bataan");
                    provincedt.Rows.Add(4, 4, "Bulacan");
                    provincedt.Rows.Add(4, 5, "Nueva Ecija");
                    provincedt.Rows.Add(4, 6, "Pampanga");
                    provincedt.Rows.Add(4, 7, "Tarlac");
                    provincedt.Rows.Add(4, 8, "Zambales");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "5")
                {
                    provincedt.Rows.Add(5, 1, "Select");
                    provincedt.Rows.Add(5, 2, "Cavite");
                    provincedt.Rows.Add(5, 3, "Laguna");
                    provincedt.Rows.Add(5, 4, "Batangas");
                    provincedt.Rows.Add(5, 5, "Quezon");
                    provincedt.Rows.Add(5, 6, "Rizal");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "6")
                {
                    provincedt.Rows.Add(6, 1, "Select");
                    provincedt.Rows.Add(6, 2, "Occidental Mindoro");
                    provincedt.Rows.Add(6, 3, "Oriental Mindoro");
                    provincedt.Rows.Add(6, 4, "Marinduque");
                    provincedt.Rows.Add(6, 5, "Romblon");
                    provincedt.Rows.Add(6, 6, "Palawan");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "7")
                {
                    provincedt.Rows.Add(7, 1, "Select");
                    provincedt.Rows.Add(7, 2, "Albay");
                    provincedt.Rows.Add(7, 3, "Camarines Norte");
                    provincedt.Rows.Add(7, 4, "Camarines Sur");
                    provincedt.Rows.Add(7, 5, "Catanduanes");
                    provincedt.Rows.Add(7, 6, "Masbate");
                    provincedt.Rows.Add(7, 7, "Sorsogon");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "8")
                {
                    provincedt.Rows.Add(8, 1, "Select");
                    provincedt.Rows.Add(8, 2, "Aklan");
                    provincedt.Rows.Add(8, 3, "Antique");
                    provincedt.Rows.Add(8, 4, "Capiz");
                    provincedt.Rows.Add(8, 5, "Guimaras");
                    provincedt.Rows.Add(8, 6, "Iloilo");
                    provincedt.Rows.Add(8, 7, "Negros Occidental");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "9")
                {
                    provincedt.Rows.Add(9, 1, "Select");
                    provincedt.Rows.Add(9, 2, "Bohol");
                    provincedt.Rows.Add(9, 3, "Cebu");
                    provincedt.Rows.Add(9, 4, "Negros Oriental");
                    provincedt.Rows.Add(9, 5, "Siquijor");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "10")
                {
                    provincedt.Rows.Add(10, 1, "Select");
                    provincedt.Rows.Add(10, 2, "Biliran");
                    provincedt.Rows.Add(10, 3, "Eastern Samar");
                    provincedt.Rows.Add(10, 4, "Leyte");
                    provincedt.Rows.Add(10, 5, "Northern Samar");
                    provincedt.Rows.Add(10, 6, "Samar (Western Samar)");
                    provincedt.Rows.Add(10, 7, "Southern Leyte");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "11")
                {
                    provincedt.Rows.Add(11, 1, "Select");
                    provincedt.Rows.Add(11, 2, "Zamboanga del Norte");
                    provincedt.Rows.Add(11, 3, "Zamboanga del Sur");
                    provincedt.Rows.Add(11, 4, "Zamboanga Sibugay");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "12")
                {
                    provincedt.Rows.Add(12, 1, "Select");
                    provincedt.Rows.Add(12, 2, "Bukidnon");
                    provincedt.Rows.Add(12, 3, "Camiguin");
                    provincedt.Rows.Add(12, 4, "Lanao del Norte");
                    provincedt.Rows.Add(12, 5, "Misamis Occidental");
                    provincedt.Rows.Add(12, 6, "Misamis Oriental");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "13")
                {
                    provincedt.Rows.Add(13, 1, "Select");
                    provincedt.Rows.Add(13, 2, "Davao del Norte");
                    provincedt.Rows.Add(13, 3, "Davao del Sur");
                    provincedt.Rows.Add(13, 4, "Davao Occidental");
                    provincedt.Rows.Add(13, 5, "Davao Oriental");
                    provincedt.Rows.Add(13, 6, "Davao de Oro");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "14")
                {
                    provincedt.Rows.Add(14, 1, "Select");
                    provincedt.Rows.Add(14, 2, "Cotabato");
                    provincedt.Rows.Add(14, 3, "Sarangani");
                    provincedt.Rows.Add(14, 4, "South Cotabato");
                    provincedt.Rows.Add(14, 5, "Sultan Kudarat");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "15")
                {
                    provincedt.Rows.Add(15, 1, "Select");
                    provincedt.Rows.Add(15, 2, "Agusan del Norte");
                    provincedt.Rows.Add(15, 3, "Agusan del Sur");
                    provincedt.Rows.Add(15, 4, "Dinagat Islands");
                    provincedt.Rows.Add(15, 5, "Surigao del Norte");
                    provincedt.Rows.Add(15, 6, "Surigao del Sur");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "16")
                {
                    provincedt.Rows.Add(16, 1, "Select");
                    provincedt.Rows.Add(16, 2, "Metro Manila");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "17")
                {
                    provincedt.Rows.Add(17, 1, "Select");
                    provincedt.Rows.Add(17, 2, "Abra");
                    provincedt.Rows.Add(17, 3, "Apayao");
                    provincedt.Rows.Add(17, 4, "Benguet");
                    provincedt.Rows.Add(17, 5, "Ifugao");
                    provincedt.Rows.Add(17, 6, "Kalinga");
                    provincedt.Rows.Add(17, 7, "Mountain Province");

                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "18")
                {
                    provincedt.Rows.Add(18, 1, "Select");
                    provincedt.Rows.Add(18, 2, "Basilan");
                    provincedt.Rows.Add(18, 3, "Lanao del Sur");
                    provincedt.Rows.Add(18, 4, "Maguindanao");
                    provincedt.Rows.Add(18, 5, "Sulu");
                    provincedt.Rows.Add(18, 6, "Tawi-Tawi");

                    citydt.Rows.Add(1, 1, "Select");
                }

                province.DataSource = provincedt;
                province.DataTextField = "ProvinceName";
                province.DataValueField = "Province ID";
                province.DataBind();

                city.DataSource = citydt;
                city.DataTextField = "CityName";
                city.DataValueField = "City ID";
                city.DataBind();
            }
        }

        protected void province_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable citydt = new DataTable();

            citydt.Columns.Add("Province ID", typeof(int));
            citydt.Columns.Add("City ID", typeof(int));
            citydt.Columns.Add("CityName");

            if (int.Parse(province.SelectedValue) > 0)
            {
                if (province.SelectedValue == "1")
                {
                    citydt.Rows.Add(1, 1, "Select");
                }
                else if (region.SelectedValue == "2")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Laoag City");
                        citydt.Rows.Add(2, 3, "Batac City");
                        citydt.Rows.Add(2, 4, "Badoc");
                        citydt.Rows.Add(2, 5, "Bangui");
                        citydt.Rows.Add(2, 6, "Burgos");
                        citydt.Rows.Add(2, 7, "Carasi");
                        citydt.Rows.Add(2, 8, "Currimao");
                        citydt.Rows.Add(2, 9, "Dingras");
                        citydt.Rows.Add(2, 10, "Dumalneg");
                        citydt.Rows.Add(2, 11, "Marcos");
                        citydt.Rows.Add(2, 12, "Nueva Era");
                        citydt.Rows.Add(2, 13, "Pagudpud");
                        citydt.Rows.Add(2, 14, "Paoay");
                        citydt.Rows.Add(2, 15, "Pasuquin");
                        citydt.Rows.Add(2, 16, "Piddig");
                        citydt.Rows.Add(2, 17, "Pinili");
                        citydt.Rows.Add(2, 18, "San Nicolas");
                        citydt.Rows.Add(2, 19, "Sarrat");
                        citydt.Rows.Add(2, 20, "Solsona");
                        citydt.Rows.Add(2, 21, "Vintar");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Vigan City");
                        citydt.Rows.Add(3, 3, "Candon City");
                        citydt.Rows.Add(3, 4, "Alilem");
                        citydt.Rows.Add(3, 5, "Banayoyo");
                        citydt.Rows.Add(3, 6, "Bantay");
                        citydt.Rows.Add(3, 7, "Burgos");
                        citydt.Rows.Add(3, 8, "Cabugao");
                        citydt.Rows.Add(3, 9, "Caoayan");
                        citydt.Rows.Add(3, 10, "Cervantes");
                        citydt.Rows.Add(3, 11, "Galimuyod");
                        citydt.Rows.Add(3, 12, "Gregorio del Pilar");
                        citydt.Rows.Add(3, 13, "Lidlidda");
                        citydt.Rows.Add(3, 14, "Magsingal");
                        citydt.Rows.Add(3, 15, "Nagbukel");
                        citydt.Rows.Add(3, 16, "Narvacan");
                        citydt.Rows.Add(3, 17, "Quirino");
                        citydt.Rows.Add(3, 18, "Salcedo");
                        citydt.Rows.Add(3, 19, "San Emilio");
                        citydt.Rows.Add(3, 20, "San Esteban");
                        citydt.Rows.Add(3, 21, "San Ildefonso");
                        citydt.Rows.Add(3, 22, "San Juan");
                        citydt.Rows.Add(3, 23, "San Vicente");
                        citydt.Rows.Add(3, 24, "Santa");
                        citydt.Rows.Add(3, 25, "Santa Catalina");
                        citydt.Rows.Add(3, 26, "Santa Cruz");
                        citydt.Rows.Add(3, 27, "Santa Lucia");
                        citydt.Rows.Add(3, 28, "Santa Maria");
                        citydt.Rows.Add(3, 29, "Santiago");
                        citydt.Rows.Add(3, 30, "Santo Domingo");
                        citydt.Rows.Add(3, 31, "Sigay");
                        citydt.Rows.Add(3, 32, "Sinait");
                        citydt.Rows.Add(3, 33, "Suyo");
                        citydt.Rows.Add(3, 34, "Tagudin");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "San Fernando City");
                        citydt.Rows.Add(4, 3, "Agoo");
                        citydt.Rows.Add(4, 4, "Aringay");
                        citydt.Rows.Add(4, 5, "Bacnotan");
                        citydt.Rows.Add(4, 6, "Bagulin");
                        citydt.Rows.Add(4, 7, "Balaoan");
                        citydt.Rows.Add(4, 8, "Bangar");
                        citydt.Rows.Add(4, 9, "Bauang");
                        citydt.Rows.Add(4, 10, "Burgos");
                        citydt.Rows.Add(4, 11, "Caba");
                        citydt.Rows.Add(4, 12, "Luna");
                        citydt.Rows.Add(4, 13, "Naguilian");
                        citydt.Rows.Add(4, 14, "Pugo");
                        citydt.Rows.Add(4, 15, "Rosario");
                        citydt.Rows.Add(4, 16, "San Gabriel");
                        citydt.Rows.Add(4, 17, "San Juan");
                        citydt.Rows.Add(4, 18, "Santo Tomas");
                        citydt.Rows.Add(4, 19, "Santol");
                        citydt.Rows.Add(4, 20, "Sudipen");
                        citydt.Rows.Add(4, 21, "Tubao");

                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Alaminos City");
                        citydt.Rows.Add(5, 3, "Dagupan City");
                        citydt.Rows.Add(5, 4, "Urdaneta City");
                        citydt.Rows.Add(5, 5, "Agno");
                        citydt.Rows.Add(5, 6, "Aguilar");
                        citydt.Rows.Add(5, 7, "Alcala");
                        citydt.Rows.Add(5, 8, "Anda");
                        citydt.Rows.Add(5, 9, "Asingan");
                        citydt.Rows.Add(5, 10, "Balungao");
                        citydt.Rows.Add(5, 11, "Bani");
                        citydt.Rows.Add(5, 12, "Basista");
                        citydt.Rows.Add(5, 13, "Bautista");
                        citydt.Rows.Add(5, 14, "Bayambang");
                        citydt.Rows.Add(5, 15, "Binalonan");
                        citydt.Rows.Add(5, 16, "Binmaley");
                        citydt.Rows.Add(5, 17, "Bolinao");
                        citydt.Rows.Add(5, 18, "Bugallon");
                        citydt.Rows.Add(5, 19, "Burgos");
                        citydt.Rows.Add(5, 20, "Calasiao");
                        citydt.Rows.Add(5, 21, "Dasol");
                        citydt.Rows.Add(5, 22, "Infanta");
                        citydt.Rows.Add(5, 23, "Labrador");
                        citydt.Rows.Add(5, 24, "Laoac");
                        citydt.Rows.Add(5, 25, "Lingayen");
                        citydt.Rows.Add(5, 26, "Mabini");
                        citydt.Rows.Add(5, 27, "Malasiqui");
                        citydt.Rows.Add(5, 28, "Manaoag");
                        citydt.Rows.Add(5, 29, "Mangaldan");
                        citydt.Rows.Add(5, 30, "Mangatarem");
                        citydt.Rows.Add(5, 31, "Mapandan");
                        citydt.Rows.Add(5, 32, "Natividad");
                        citydt.Rows.Add(5, 33, "Pozorrubio");
                        citydt.Rows.Add(5, 34, "Rosales");
                        citydt.Rows.Add(5, 35, "San Carlos City");
                        citydt.Rows.Add(5, 36, "San Fabian");
                        citydt.Rows.Add(5, 37, "San Jacinto");
                        citydt.Rows.Add(5, 38, "San Manuel");
                        citydt.Rows.Add(5, 39, "San Nicolas");
                        citydt.Rows.Add(5, 40, "San Quintin");
                        citydt.Rows.Add(5, 41, "Santa Barbara");
                        citydt.Rows.Add(5, 42, "Santa Maria");
                        citydt.Rows.Add(5, 43, "Santo Tomas");
                        citydt.Rows.Add(5, 44, "Sison");
                        citydt.Rows.Add(5, 45, "Sual");
                        citydt.Rows.Add(5, 46, "Tayug");
                        citydt.Rows.Add(5, 47, "Umingan");
                        citydt.Rows.Add(5, 48, "Urbiztondo");
                        citydt.Rows.Add(5, 49, "Villasis");
                    }
                }
                else if (region.SelectedValue == "3")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Basco");
                        citydt.Rows.Add(2, 3, "Itbayat");
                        citydt.Rows.Add(2, 4, "Ivana");
                        citydt.Rows.Add(2, 5, "Mahatao");
                        citydt.Rows.Add(2, 6, "Sabtang");
                        citydt.Rows.Add(2, 7, "Uyugan");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Tuguegarao City");
                        citydt.Rows.Add(3, 3, "Abulug");
                        citydt.Rows.Add(3, 4, "Alcala");
                        citydt.Rows.Add(3, 5, "Allacapan");
                        citydt.Rows.Add(3, 6, "Amulung");
                        citydt.Rows.Add(3, 7, "Aparri");
                        citydt.Rows.Add(3, 8, "Baggao");
                        citydt.Rows.Add(3, 9, "Ballesteros");
                        citydt.Rows.Add(3, 10, "Buguey");
                        citydt.Rows.Add(3, 11, "Calayan");
                        citydt.Rows.Add(3, 12, "Camalaniugan");
                        citydt.Rows.Add(3, 13, "Claveria");
                        citydt.Rows.Add(3, 14, "Enrile");
                        citydt.Rows.Add(3, 15, "Gattaran");
                        citydt.Rows.Add(3, 16, "Gonzaga");
                        citydt.Rows.Add(3, 17, "Iguig");
                        citydt.Rows.Add(3, 18, "Lal-lo");
                        citydt.Rows.Add(3, 19, "Lasam");
                        citydt.Rows.Add(3, 20, "Piat");
                        citydt.Rows.Add(3, 21, "Rizal");
                        citydt.Rows.Add(3, 22, "Sanchez Mira");
                        citydt.Rows.Add(3, 23, "Santa Ana");
                        citydt.Rows.Add(3, 24, "Santa Praxedes");
                        citydt.Rows.Add(3, 25, "Santa Teresita");
                        citydt.Rows.Add(3, 26, "Santo Niño (Faire)");
                        citydt.Rows.Add(3, 27, "Solana");
                        citydt.Rows.Add(3, 28, "Tuao");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Ilagan City");
                        citydt.Rows.Add(4, 3, "Santiago City");
                        citydt.Rows.Add(4, 4, "Alicia");
                        citydt.Rows.Add(4, 5, "Angadanan");
                        citydt.Rows.Add(4, 6, "Aurora");
                        citydt.Rows.Add(4, 7, "Benito Soliven");
                        citydt.Rows.Add(4, 8, "Burgos");
                        citydt.Rows.Add(4, 9, "Cabagan");
                        citydt.Rows.Add(4, 10, "Cabatuan");
                        citydt.Rows.Add(4, 11, "Cordon");
                        citydt.Rows.Add(4, 12, "Delfin Albano");
                        citydt.Rows.Add(4, 13, "Dinapigue");
                        citydt.Rows.Add(4, 14, "Divilacan");
                        citydt.Rows.Add(4, 15, "Echague");
                        citydt.Rows.Add(4, 16, "Gamu");
                        citydt.Rows.Add(4, 17, "Jones");
                        citydt.Rows.Add(4, 18, "Luna");
                        citydt.Rows.Add(4, 19, "Maconacon");
                        citydt.Rows.Add(4, 20, "Mallig");
                        citydt.Rows.Add(4, 21, "Naguilian");
                        citydt.Rows.Add(4, 22, "Palanan");
                        citydt.Rows.Add(4, 23, "Quezon");
                        citydt.Rows.Add(4, 24, "Quirino");
                        citydt.Rows.Add(4, 25, "Ramon");
                        citydt.Rows.Add(4, 26, "Reina Mercedes");
                        citydt.Rows.Add(4, 27, "Roxas");
                        citydt.Rows.Add(4, 28, "San Agustin");
                        citydt.Rows.Add(4, 29, "San Guillermo");
                        citydt.Rows.Add(4, 30, "San Isidro");
                        citydt.Rows.Add(4, 31, "San Manuel");
                        citydt.Rows.Add(4, 32, "San Mariano");
                        citydt.Rows.Add(4, 33, "San Mateo");
                        citydt.Rows.Add(4, 34, "San Pablo");
                        citydt.Rows.Add(4, 35, "Santa Maria");
                        citydt.Rows.Add(4, 36, "Santo Tomas");
                        citydt.Rows.Add(4, 37, "Tumauini");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Bayombong");
                        citydt.Rows.Add(5, 3, "Alfonso Castañeda");
                        citydt.Rows.Add(5, 4, "Ambaguio");
                        citydt.Rows.Add(5, 5, "Aritao");
                        citydt.Rows.Add(5, 6, "Bagabag");
                        citydt.Rows.Add(5, 7, "Bambang");
                        citydt.Rows.Add(5, 8, "Diadi");
                        citydt.Rows.Add(5, 9, "Dupax del Norte");
                        citydt.Rows.Add(5, 10, "Dupax del Sur");
                        citydt.Rows.Add(5, 11, "Kasibu");
                        citydt.Rows.Add(5, 12, "Kayapa");
                        citydt.Rows.Add(5, 13, "Quezon");
                        citydt.Rows.Add(5, 14, "Santa Fe");
                        citydt.Rows.Add(5, 15, "Solano");
                        citydt.Rows.Add(5, 16, "Villaverde");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Cabarroguis");
                        citydt.Rows.Add(6, 3, "Aglipay");
                        citydt.Rows.Add(6, 4, "Diffun");
                        citydt.Rows.Add(6, 5, "Maddela");
                        citydt.Rows.Add(6, 6, "Nagtipunan");
                        citydt.Rows.Add(6, 7, "Saguday");
                    }
                }
                else if (region.SelectedValue == "4")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Baler");
                        citydt.Rows.Add(2, 3, "Casiguran");
                        citydt.Rows.Add(2, 4, "Dilasag");
                        citydt.Rows.Add(2, 5, "Dingalan");
                        citydt.Rows.Add(2, 6, "Dinalungan");
                        citydt.Rows.Add(2, 7, "Dipaculao");
                        citydt.Rows.Add(2, 8, "Maria Aurora");
                        citydt.Rows.Add(2, 9, "San Luis");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Balanga City");
                        citydt.Rows.Add(3, 3, "Abucay");
                        citydt.Rows.Add(3, 4, "Bagac");
                        citydt.Rows.Add(3, 5, "Dinalupihan");
                        citydt.Rows.Add(3, 6, "Hermosa");
                        citydt.Rows.Add(3, 7, "Limay");
                        citydt.Rows.Add(3, 8, "Mariveles");
                        citydt.Rows.Add(3, 9, "Morong");
                        citydt.Rows.Add(3, 10, "Orani");
                        citydt.Rows.Add(3, 11, "Orion");
                        citydt.Rows.Add(3, 12, "Pilar");
                        citydt.Rows.Add(3, 13, "Samal");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Malolos City");
                        citydt.Rows.Add(4, 3, "Meycauayan City");
                        citydt.Rows.Add(4, 4, "San Jose del Monte City");
                        citydt.Rows.Add(4, 5, "Angat");
                        citydt.Rows.Add(4, 6, "Balagtas");
                        citydt.Rows.Add(4, 7, "Baliuag");
                        citydt.Rows.Add(4, 8, "Bocaue");
                        citydt.Rows.Add(4, 9, "Bulacan");
                        citydt.Rows.Add(4, 10, "Bustos");
                        citydt.Rows.Add(4, 11, "Calumpit");
                        citydt.Rows.Add(4, 12, "Doña Remedios Trinidad");
                        citydt.Rows.Add(4, 13, "Guiguinto");
                        citydt.Rows.Add(4, 14, "Hagonoy");
                        citydt.Rows.Add(4, 15, "Marilao");
                        citydt.Rows.Add(4, 16, "Norzagaray");
                        citydt.Rows.Add(4, 17, "Obando");
                        citydt.Rows.Add(4, 18, "Pandi");
                        citydt.Rows.Add(4, 19, "Paombong");
                        citydt.Rows.Add(4, 20, "Plaridel");
                        citydt.Rows.Add(4, 21, "Pulilan");
                        citydt.Rows.Add(4, 22, "San Ildefonso");
                        citydt.Rows.Add(4, 23, "San Miguel");
                        citydt.Rows.Add(4, 24, "San Rafael");
                        citydt.Rows.Add(4, 25, "Santa Maria");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Palayan City");
                        citydt.Rows.Add(5, 3, "Cabanatuan City");
                        citydt.Rows.Add(5, 4, "Gapan City");
                        citydt.Rows.Add(5, 5, "Science City of Muñoz");
                        citydt.Rows.Add(5, 6, "San Jose City");
                        citydt.Rows.Add(5, 7, "Aliaga");
                        citydt.Rows.Add(5, 8, "Bongabon");
                        citydt.Rows.Add(5, 9, "Cabiao");
                        citydt.Rows.Add(5, 10, "Carranglan");
                        citydt.Rows.Add(5, 11, "Cuyapo");
                        citydt.Rows.Add(5, 12, "Gabaldon (Bitulok & Sabani)");
                        citydt.Rows.Add(5, 13, "General Mamerto Natividad");
                        citydt.Rows.Add(5, 14, "General Tinio (Papaya)");
                        citydt.Rows.Add(5, 15, "Guimba");
                        citydt.Rows.Add(5, 16, "Jaen");
                        citydt.Rows.Add(5, 17, "Laur");
                        citydt.Rows.Add(5, 18, "Licab");
                        citydt.Rows.Add(5, 19, "Llanera");
                        citydt.Rows.Add(5, 20, "Lupao");
                        citydt.Rows.Add(5, 21, "Nampicuan");
                        citydt.Rows.Add(5, 22, "Pantabangan");
                        citydt.Rows.Add(5, 23, "Peñaranda");
                        citydt.Rows.Add(5, 24, "Quezon");
                        citydt.Rows.Add(5, 25, "Rizal");
                        citydt.Rows.Add(5, 26, "San Antonio");
                        citydt.Rows.Add(5, 27, "San Isidro");
                        citydt.Rows.Add(5, 28, "San Leonardo");
                        citydt.Rows.Add(5, 29, "Santa Rosa");
                        citydt.Rows.Add(5, 30, "Santo Domingo");
                        citydt.Rows.Add(5, 31, "Talavera");
                        citydt.Rows.Add(5, 32, "Talugtug");
                        citydt.Rows.Add(5, 33, "Zaragoza");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Angeles City");
                        citydt.Rows.Add(6, 3, "Mabalacat City");
                        citydt.Rows.Add(6, 4, "San Fernando City");
                        citydt.Rows.Add(6, 5, "Apalit");
                        citydt.Rows.Add(6, 6, "Arayat");
                        citydt.Rows.Add(6, 7, "Bacolor");
                        citydt.Rows.Add(6, 8, "Candaba");
                        citydt.Rows.Add(6, 9, "Floridablanca");
                        citydt.Rows.Add(6, 10, "Guagua");
                        citydt.Rows.Add(6, 11, "Lubao");
                        citydt.Rows.Add(6, 12, "Macabebe");
                        citydt.Rows.Add(6, 13, "Magalang");
                        citydt.Rows.Add(6, 14, "Masantol");
                        citydt.Rows.Add(6, 15, "Mexico");
                        citydt.Rows.Add(6, 16, "Minalin");
                        citydt.Rows.Add(6, 17, "Porac");
                        citydt.Rows.Add(6, 18, "San Luis");
                        citydt.Rows.Add(6, 19, "San Simon");
                        citydt.Rows.Add(6, 20, "Santa Ana");
                        citydt.Rows.Add(6, 21, "Santa Rita");
                        citydt.Rows.Add(6, 22, "Santo Tomas");
                        citydt.Rows.Add(6, 23, "Sasmuan");
                    }
                    else if (province.SelectedValue == "7")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Tarlac City");
                        citydt.Rows.Add(7, 3, "Capas");
                        citydt.Rows.Add(7, 4, "Concepcion");
                        citydt.Rows.Add(7, 5, "Gerona");
                        citydt.Rows.Add(7, 6, "La Paz");
                        citydt.Rows.Add(7, 7, "Mayantoc");
                        citydt.Rows.Add(7, 8, "Moncada");
                        citydt.Rows.Add(7, 9, "Paniqui");
                        citydt.Rows.Add(7, 10, "Pura");
                        citydt.Rows.Add(7, 11, "Ramos");
                        citydt.Rows.Add(7, 12, "San Clemente");
                        citydt.Rows.Add(7, 13, "San Jose");
                        citydt.Rows.Add(7, 14, "San Manuel");
                        citydt.Rows.Add(7, 15, "Santa Ignacia");
                        citydt.Rows.Add(7, 16, "Victoria");
                    }
                    else if (province.SelectedValue == "8")
                    {
                        citydt.Rows.Add(8, 1, "Select");
                        citydt.Rows.Add(8, 2, "Olongapo City");
                        citydt.Rows.Add(8, 3, "Botolan");
                        citydt.Rows.Add(8, 4, "Cabangan");
                        citydt.Rows.Add(8, 5, "Candelaria");
                        citydt.Rows.Add(8, 6, "Castillejos");
                        citydt.Rows.Add(8, 7, "Iba");
                        citydt.Rows.Add(8, 8, "Masinloc");
                        citydt.Rows.Add(8, 9, "Palauig");
                        citydt.Rows.Add(8, 10, "San Antonio");
                        citydt.Rows.Add(8, 11, "San Felipe");
                        citydt.Rows.Add(8, 12, "San Marcelino");
                        citydt.Rows.Add(8, 13, "San Narciso");
                        citydt.Rows.Add(8, 14, "Santa Cruz");
                        citydt.Rows.Add(8, 15, "Subic");
                    }
                }
                else if (region.SelectedValue == "5")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Cavite City");
                        citydt.Rows.Add(3, 3, "Dasmariñas City");
                        citydt.Rows.Add(3, 4, "Bacoor City");
                        citydt.Rows.Add(3, 5, "Imus City");
                        citydt.Rows.Add(3, 6, "Tagaytay City");
                        citydt.Rows.Add(3, 7, "Trece Martires City");
                        citydt.Rows.Add(3, 8, "Alfonso");
                        citydt.Rows.Add(3, 9, "Amadeo");
                        citydt.Rows.Add(3, 10, "Carmona");
                        citydt.Rows.Add(3, 11, "General Emilio Aguinaldo (Bailen)");
                        citydt.Rows.Add(3, 12, "General Mariano Alvarez (GMA)");
                        citydt.Rows.Add(3, 13, "Indang");
                        citydt.Rows.Add(3, 14, "Kawit");
                        citydt.Rows.Add(3, 15, "Magallanes");
                        citydt.Rows.Add(3, 16, "Maragondon");
                        citydt.Rows.Add(3, 17, "Mendez");
                        citydt.Rows.Add(3, 18, "Naic");
                        citydt.Rows.Add(3, 19, "Noveleta");
                        citydt.Rows.Add(3, 20, "Rosario");
                        citydt.Rows.Add(3, 21, "Silang");
                        citydt.Rows.Add(3, 22, "Tanza");
                        citydt.Rows.Add(3, 23, "Ternate");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Santa Rosa City");
                        citydt.Rows.Add(4, 3, "Biñan City");
                        citydt.Rows.Add(4, 4, "Calamba City");
                        citydt.Rows.Add(4, 5, "San Pedro City");
                        citydt.Rows.Add(4, 6, "Cabuyao City");
                        citydt.Rows.Add(4, 7, "Santa Cruz");
                        citydt.Rows.Add(4, 8, "Alaminos");
                        citydt.Rows.Add(4, 9, "Bay");
                        citydt.Rows.Add(4, 10, "Calauan");
                        citydt.Rows.Add(4, 11, "Cavinti");
                        citydt.Rows.Add(4, 12, "Famy");
                        citydt.Rows.Add(4, 13, "Kalayaan");
                        citydt.Rows.Add(4, 14, "Liliw");
                        citydt.Rows.Add(4, 15, "Los Baños");
                        citydt.Rows.Add(4, 16, "Luisiana");
                        citydt.Rows.Add(4, 17, "Lumban");
                        citydt.Rows.Add(4, 18, "Mabitac");
                        citydt.Rows.Add(4, 19, "Magdalena");
                        citydt.Rows.Add(4, 20, "Majayjay");
                        citydt.Rows.Add(4, 21, "Nagcarlan");
                        citydt.Rows.Add(4, 22, "Paete");
                        citydt.Rows.Add(4, 23, "Pagsanjan");
                        citydt.Rows.Add(4, 24, "Pakil");
                        citydt.Rows.Add(4, 25, "Pangil");
                        citydt.Rows.Add(4, 26, "Pila");
                        citydt.Rows.Add(4, 27, "Rizal");
                        citydt.Rows.Add(4, 28, "San Pablo City");
                        citydt.Rows.Add(4, 29, "San Antonio");
                        citydt.Rows.Add(4, 30, "San Juan");
                        citydt.Rows.Add(4, 31, "San Pablo City");
                        citydt.Rows.Add(4, 32, "Santa Cruz");
                        citydt.Rows.Add(4, 33, "Santa Maria");
                        citydt.Rows.Add(4, 34, "Santa Rosa City");
                        citydt.Rows.Add(4, 35, "Siniloan");
                        citydt.Rows.Add(4, 36, "Victoria");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Batangas City");
                        citydt.Rows.Add(5, 3, "Lipa City");
                        citydt.Rows.Add(5, 4, "Tanauan City");
                        citydt.Rows.Add(5, 5, "Sto. Tomas City");
                        citydt.Rows.Add(5, 6, "Agoncillo");
                        citydt.Rows.Add(5, 7, "Alitagtag");
                        citydt.Rows.Add(5, 8, "Balayan");
                        citydt.Rows.Add(5, 9, "Balete");
                        citydt.Rows.Add(5, 10, "Bauan");
                        citydt.Rows.Add(5, 11, "Calaca");
                        citydt.Rows.Add(5, 12, "Calatagan");
                        citydt.Rows.Add(5, 13, "Cuenca");
                        citydt.Rows.Add(5, 14, "Ibaan");
                        citydt.Rows.Add(5, 15, "Laurel");
                        citydt.Rows.Add(5, 16, "Lemery");
                        citydt.Rows.Add(5, 17, "Lian");
                        citydt.Rows.Add(5, 18, "Lobo");
                        citydt.Rows.Add(5, 19, "Mabini");
                        citydt.Rows.Add(5, 20, "Malvar");
                        citydt.Rows.Add(5, 21, "Mataasnakahoy");
                        citydt.Rows.Add(5, 22, "Nasugbu");
                        citydt.Rows.Add(5, 23, "Padre Garcia");
                        citydt.Rows.Add(5, 24, "Rosario");
                        citydt.Rows.Add(5, 25, "San Jose");
                        citydt.Rows.Add(5, 26, "San Juan");
                        citydt.Rows.Add(5, 27, "San Luis");
                        citydt.Rows.Add(5, 28, "San Nicolas");
                        citydt.Rows.Add(5, 29, "San Pascual");
                        citydt.Rows.Add(5, 30, "Santa Teresita");
                        citydt.Rows.Add(5, 31, "Santo Tomas");
                        citydt.Rows.Add(5, 32, "Taal");
                        citydt.Rows.Add(5, 33, "Talisay");
                        citydt.Rows.Add(5, 34, "Taysan");
                        citydt.Rows.Add(5, 35, "Tingloy");
                        citydt.Rows.Add(5, 36, "Tuy");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Lucena City");
                        citydt.Rows.Add(6, 3, "Tayabas City");
                        citydt.Rows.Add(6, 4, "Candelaria");
                        citydt.Rows.Add(6, 5, "Sariaya");
                        citydt.Rows.Add(6, 6, "Tiaong");
                        citydt.Rows.Add(6, 7, "Agdangan");
                        citydt.Rows.Add(6, 8, "Alabat");
                        citydt.Rows.Add(6, 9, "Atimonan");
                        citydt.Rows.Add(6, 10, "Buenavista");
                        citydt.Rows.Add(6, 11, "Burdeos");
                        citydt.Rows.Add(6, 12, "Calauag");
                        citydt.Rows.Add(6, 13, "Catanaun");
                        citydt.Rows.Add(6, 14, "Dolores");
                        citydt.Rows.Add(6, 15, "General Luna");
                        citydt.Rows.Add(6, 16, "General Nakar");
                        citydt.Rows.Add(6, 17, "Guinayangan");
                        citydt.Rows.Add(6, 18, "Gumaca");
                        citydt.Rows.Add(6, 19, "Infanta");
                        citydt.Rows.Add(6, 20, "Jomalig");
                        citydt.Rows.Add(6, 21, "Lopez");
                        citydt.Rows.Add(6, 22, "Lucban");
                        citydt.Rows.Add(6, 23, "Macalelon");
                        citydt.Rows.Add(6, 24, "Mauban");
                        citydt.Rows.Add(6, 25, "Mulanay");
                        citydt.Rows.Add(6, 26, "Padre Burgos");
                        citydt.Rows.Add(6, 27, "Pagbilao");
                        citydt.Rows.Add(6, 28, "Panukulan");
                        citydt.Rows.Add(6, 29, "Patnanungan");
                        citydt.Rows.Add(6, 30, "Perez");
                        citydt.Rows.Add(6, 31, "Pitogo");
                        citydt.Rows.Add(6, 32, "Plaridel");
                        citydt.Rows.Add(6, 33, "Polillo");
                        citydt.Rows.Add(6, 34, "Quezon");
                        citydt.Rows.Add(6, 35, "Real");
                        citydt.Rows.Add(6, 36, "Sampaloc");
                        citydt.Rows.Add(6, 37, "San Andres");
                        citydt.Rows.Add(6, 38, "San Antonio");
                        citydt.Rows.Add(6, 39, "San Francisco");
                        citydt.Rows.Add(6, 40, "San Narciso");
                        citydt.Rows.Add(6, 41, "Sariaya");
                        citydt.Rows.Add(6, 42, "Tagkawayan");
                        citydt.Rows.Add(6, 43, "Tiaong");
                        citydt.Rows.Add(6, 44, "Unisan");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Antipolo City");
                        citydt.Rows.Add(7, 3, "Angono");
                        citydt.Rows.Add(7, 4, "Baras");
                        citydt.Rows.Add(7, 5, "Binangonan");
                        citydt.Rows.Add(7, 6, "Cainta");
                        citydt.Rows.Add(7, 7, "Cardona");
                        citydt.Rows.Add(7, 8, "Jala-Jala");
                        citydt.Rows.Add(7, 9, "Morong");
                        citydt.Rows.Add(7, 10, "Pililla");
                        citydt.Rows.Add(7, 11, "Rodriguez (Montalban)");
                        citydt.Rows.Add(7, 12, "San Mateo");
                        citydt.Rows.Add(7, 13, "Tanay");
                        citydt.Rows.Add(7, 14, "Taytay");
                        citydt.Rows.Add(7, 15, "Teresa");
                    }
                }
                else if (region.SelectedValue == "6")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Abra de Ilog");
                        citydt.Rows.Add(2, 3, "Calintaan");
                        citydt.Rows.Add(2, 4, "Looc");
                        citydt.Rows.Add(2, 5, "Lubang");
                        citydt.Rows.Add(2, 6, "Magsaysay");
                        citydt.Rows.Add(2, 7, "Mamburao (Capital)");
                        citydt.Rows.Add(2, 8, "Paluan");
                        citydt.Rows.Add(2, 9, "Rizal");
                        citydt.Rows.Add(2, 10, "Sablayan");
                        citydt.Rows.Add(2, 11, "San Jose");
                        citydt.Rows.Add(2, 12, "Santa Cruz");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Baco");
                        citydt.Rows.Add(3, 3, "Bansud");
                        citydt.Rows.Add(3, 4, "Bongabong");
                        citydt.Rows.Add(3, 5, "Bulalacao");
                        citydt.Rows.Add(3, 6, "Calapan City (Capital)");
                        citydt.Rows.Add(3, 7, "Gloria");
                        citydt.Rows.Add(3, 8, "Mansalay");
                        citydt.Rows.Add(3, 9, "Naujan");
                        citydt.Rows.Add(3, 10, "Pinamalayan");
                        citydt.Rows.Add(3, 11, "Pola");
                        citydt.Rows.Add(3, 12, "Puerto Galera");
                        citydt.Rows.Add(3, 13, "Roxas");
                        citydt.Rows.Add(3, 14, "San Teodoro");
                        citydt.Rows.Add(3, 15, "Socorro");
                        citydt.Rows.Add(3, 16, "Victoria");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Boac (Capital)");
                        citydt.Rows.Add(4, 3, "Buenavista");
                        citydt.Rows.Add(4, 4, "Gasan");
                        citydt.Rows.Add(4, 5, "Mogpog");
                        citydt.Rows.Add(4, 6, "Santa Cruz");
                        citydt.Rows.Add(4, 7, "Torrijos");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Alcantara");
                        citydt.Rows.Add(5, 3, "Banton");
                        citydt.Rows.Add(5, 4, "Cajidiocan");
                        citydt.Rows.Add(5, 5, "Calatrava");
                        citydt.Rows.Add(5, 6, "Concepcion");
                        citydt.Rows.Add(5, 7, "Corcuera");
                        citydt.Rows.Add(5, 8, "Ferrol");
                        citydt.Rows.Add(5, 9, "Looc");
                        citydt.Rows.Add(5, 10, "Magdiwang");
                        citydt.Rows.Add(5, 11, "Odiongan (Capital)");
                        citydt.Rows.Add(5, 12, "Romblon");
                        citydt.Rows.Add(5, 13, "San Agustin");
                        citydt.Rows.Add(5, 14, "San Andres");
                        citydt.Rows.Add(5, 15, "San Fernando");
                        citydt.Rows.Add(5, 16, "San Jose");
                        citydt.Rows.Add(5, 17, "Santa Fe");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Puerto Princesa City");
                        citydt.Rows.Add(6, 3, "Aborlan");
                        citydt.Rows.Add(6, 4, "Agutaya");
                        citydt.Rows.Add(6, 5, "Araceli");
                        citydt.Rows.Add(6, 6, "Balabac");
                        citydt.Rows.Add(6, 7, "Bataraza");
                        citydt.Rows.Add(6, 8, "Brooke's Point");
                        citydt.Rows.Add(6, 9, "Busuanga");
                        citydt.Rows.Add(6, 10, "Cagayancillo");
                        citydt.Rows.Add(6, 11, "Coron");
                        citydt.Rows.Add(6, 12, "Culion");
                        citydt.Rows.Add(6, 13, "Cuyo");
                        citydt.Rows.Add(6, 14, "Dumaran");
                        citydt.Rows.Add(6, 15, "El Nido");
                        citydt.Rows.Add(6, 16, "Kalayaan");
                        citydt.Rows.Add(6, 17, "Linapacan");
                        citydt.Rows.Add(6, 18, "Magsaysay");
                        citydt.Rows.Add(6, 19, "Narra");
                        citydt.Rows.Add(6, 20, "Quezon");
                        citydt.Rows.Add(6, 21, "Rizal");
                        citydt.Rows.Add(6, 22, "Roxas");
                        citydt.Rows.Add(6, 23, "San Vicente");
                        citydt.Rows.Add(6, 24, "Sofronio Española");
                        citydt.Rows.Add(6, 25, "Taytay");
                    }
                }
                else if (region.SelectedValue == "7")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Legazpi City");
                        citydt.Rows.Add(2, 3, "Tabaco City");
                        citydt.Rows.Add(2, 4, "Ligao City");
                        citydt.Rows.Add(2, 5, "Bacacay");
                        citydt.Rows.Add(2, 6, "Camalig");
                        citydt.Rows.Add(2, 7, "Daraga");
                        citydt.Rows.Add(2, 8, "Guinobatan");
                        citydt.Rows.Add(2, 9, "Jovellar");
                        citydt.Rows.Add(2, 10, "Libon");
                        citydt.Rows.Add(2, 11, "Malilipot");
                        citydt.Rows.Add(2, 12, "Malinao");
                        citydt.Rows.Add(2, 13, "Manito");
                        citydt.Rows.Add(2, 14, "Oas");
                        citydt.Rows.Add(2, 15, "Pio Duran");
                        citydt.Rows.Add(2, 16, "Polangui");
                        citydt.Rows.Add(2, 17, "Rapu-Rapu");
                        citydt.Rows.Add(2, 18, "Santo Domingo");
                        citydt.Rows.Add(2, 19, "Tiwi");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Basud");
                        citydt.Rows.Add(3, 3, "Capalonga");
                        citydt.Rows.Add(3, 4, "Daet (Capital)");
                        citydt.Rows.Add(3, 5, "Jose Panganiban");
                        citydt.Rows.Add(3, 6, "Labo");
                        citydt.Rows.Add(3, 7, "Mercedes");
                        citydt.Rows.Add(3, 8, "Paracale");
                        citydt.Rows.Add(3, 9, "San Lorenzo Ruiz (Imelda)");
                        citydt.Rows.Add(3, 10, "San Vicente");
                        citydt.Rows.Add(3, 11, "Santa Elena");
                        citydt.Rows.Add(3, 12, "Talisay");
                        citydt.Rows.Add(3, 13, "Vinzons");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Iriga City");
                        citydt.Rows.Add(4, 3, "Naga City");
                        citydt.Rows.Add(4, 4, "Baao");
                        citydt.Rows.Add(4, 5, "Balatan");
                        citydt.Rows.Add(4, 6, "Bato");
                        citydt.Rows.Add(4, 7, "Bombon");
                        citydt.Rows.Add(4, 8, "Buhi");
                        citydt.Rows.Add(4, 9, "Bula");
                        citydt.Rows.Add(4, 10, "Calabanga");
                        citydt.Rows.Add(4, 11, "Camaligan");
                        citydt.Rows.Add(4, 12, "Canaman");
                        citydt.Rows.Add(4, 13, "Caramoan");
                        citydt.Rows.Add(4, 14, "Del Gallego");
                        citydt.Rows.Add(4, 15, "Gainza");
                        citydt.Rows.Add(4, 16, "Garchitorena");
                        citydt.Rows.Add(4, 17, "Goa");
                        citydt.Rows.Add(4, 18, "Lagonoy");
                        citydt.Rows.Add(4, 19, "Libmanan");
                        citydt.Rows.Add(4, 20, "Lupi");
                        citydt.Rows.Add(4, 21, "Magarao");
                        citydt.Rows.Add(4, 22, "Milaor");
                        citydt.Rows.Add(4, 23, "Minalabac");
                        citydt.Rows.Add(4, 24, "Nabua");
                        citydt.Rows.Add(4, 25, "Ocampo");
                        citydt.Rows.Add(4, 26, "Pamplona");
                        citydt.Rows.Add(4, 27, "Pasacao");
                        citydt.Rows.Add(4, 28, "Pili (Capital)");
                        citydt.Rows.Add(4, 29, "Presentacion (Parubcan)");
                        citydt.Rows.Add(4, 30, "Ragay");
                        citydt.Rows.Add(4, 31, "Sagnay");
                        citydt.Rows.Add(4, 32, "San Fernando");
                        citydt.Rows.Add(4, 33, "San Jose");
                        citydt.Rows.Add(4, 34, "Sipocot");
                        citydt.Rows.Add(4, 35, "Siruma");
                        citydt.Rows.Add(4, 36, "Tigaon");
                        citydt.Rows.Add(4, 37, "Tinambac");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Bagamanoc");
                        citydt.Rows.Add(5, 3, "Baras");
                        citydt.Rows.Add(5, 4, "Bato");
                        citydt.Rows.Add(5, 5, "Caramoran");
                        citydt.Rows.Add(5, 6, "Gigmoto");
                        citydt.Rows.Add(5, 7, "Pandan");
                        citydt.Rows.Add(5, 8, "Panganiban (Payo)");
                        citydt.Rows.Add(5, 9, "San Andres (Calolbon)");
                        citydt.Rows.Add(5, 10, "San Miguel");
                        citydt.Rows.Add(5, 11, "Viga");
                        citydt.Rows.Add(5, 12, "Virac (Capital)");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Masbate City (Capital)");
                        citydt.Rows.Add(6, 3, "Aroroy");
                        citydt.Rows.Add(6, 4, "Baleno");
                        citydt.Rows.Add(6, 5, "Balud");
                        citydt.Rows.Add(6, 6, "Batuan");
                        citydt.Rows.Add(6, 7, "Cataingan");
                        citydt.Rows.Add(6, 8, "Cawayan");
                        citydt.Rows.Add(6, 9, "Claveria");
                        citydt.Rows.Add(6, 10, "Dimasalang");
                        citydt.Rows.Add(6, 11, "Esperanza");
                        citydt.Rows.Add(6, 12, "Mandaon");
                        citydt.Rows.Add(6, 13, "Milagros");
                        citydt.Rows.Add(6, 14, "Mobo");
                        citydt.Rows.Add(6, 15, "Monreal");
                        citydt.Rows.Add(6, 16, "Palanas");
                        citydt.Rows.Add(6, 17, "Pio V. Corpuz");
                        citydt.Rows.Add(6, 18, "Placer");
                        citydt.Rows.Add(6, 19, "San Fernando");
                        citydt.Rows.Add(6, 20, "San Jacinto");
                        citydt.Rows.Add(6, 21, "San Pascual");
                        citydt.Rows.Add(6, 22, "Uson");
                    }
                    else if (province.SelectedValue == "7")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Sorsogon City (Capital)");
                        citydt.Rows.Add(7, 3, "Barcelona");
                        citydt.Rows.Add(7, 4, "Bulan");
                        citydt.Rows.Add(7, 5, "Bulusan");
                        citydt.Rows.Add(7, 6, "Casiguran");
                        citydt.Rows.Add(7, 7, "Castilla");
                        citydt.Rows.Add(7, 8, "Donsol");
                        citydt.Rows.Add(7, 9, "Gubat");
                        citydt.Rows.Add(7, 10, "Irosin");
                        citydt.Rows.Add(7, 11, "Juban");
                        citydt.Rows.Add(7, 12, "Magallanes");
                        citydt.Rows.Add(7, 13, "Matnog");
                        citydt.Rows.Add(7, 14, "Pilar");
                        citydt.Rows.Add(7, 15, "Prieto Diaz");
                        citydt.Rows.Add(7, 16, "Santa Magdalena");
                    }
                }
                else if (region.SelectedValue == "8")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Altavas");
                        citydt.Rows.Add(2, 3, "Balete");
                        citydt.Rows.Add(2, 4, "Banga");
                        citydt.Rows.Add(2, 5, "Batan");
                        citydt.Rows.Add(2, 6, "Buruanga");
                        citydt.Rows.Add(2, 7, "Ibajay");
                        citydt.Rows.Add(2, 8, "Kalibo (Capital)");
                        citydt.Rows.Add(2, 9, "Lezo");
                        citydt.Rows.Add(2, 10, "Libacao");
                        citydt.Rows.Add(2, 11, "Madalag");
                        citydt.Rows.Add(2, 12, "Makato");
                        citydt.Rows.Add(2, 13, "Malay");
                        citydt.Rows.Add(2, 14, "Malinao");
                        citydt.Rows.Add(2, 15, "Nabas");
                        citydt.Rows.Add(2, 16, "New Washington");
                        citydt.Rows.Add(2, 17, "Numancia");
                        citydt.Rows.Add(2, 18, "Tangalan");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Anini-y");
                        citydt.Rows.Add(3, 3, "Barbaza");
                        citydt.Rows.Add(3, 4, "Belison");
                        citydt.Rows.Add(3, 5, "Bugasong");
                        citydt.Rows.Add(3, 6, "Caluya");
                        citydt.Rows.Add(3, 7, "Culasi");
                        citydt.Rows.Add(3, 8, "Hamtic");
                        citydt.Rows.Add(3, 9, "Laua-an");
                        citydt.Rows.Add(3, 10, "Libertad");
                        citydt.Rows.Add(3, 11, "Pandan");
                        citydt.Rows.Add(3, 12, "Patnongon");
                        citydt.Rows.Add(3, 13, "San Jose (Capital)");
                        citydt.Rows.Add(3, 14, "San Remigio");
                        citydt.Rows.Add(3, 15, "Sebaste");
                        citydt.Rows.Add(3, 16, "Sibalom");
                        citydt.Rows.Add(3, 17, "Tibiao");
                        citydt.Rows.Add(3, 18, "Tobias Fornier (Dao)");
                        citydt.Rows.Add(3, 19, "Valderrama");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Cuartero");
                        citydt.Rows.Add(4, 3, "Dao");
                        citydt.Rows.Add(4, 4, "Dumalag");
                        citydt.Rows.Add(4, 5, "Dumarao");
                        citydt.Rows.Add(4, 6, "Ivisan");
                        citydt.Rows.Add(4, 7, "Jamindan");
                        citydt.Rows.Add(4, 8, "Maayon");
                        citydt.Rows.Add(4, 9, "Mambusao");
                        citydt.Rows.Add(4, 10, "Panay");
                        citydt.Rows.Add(4, 11, "Panitan");
                        citydt.Rows.Add(4, 12, "Pilar");
                        citydt.Rows.Add(4, 13, "Pontevedra");
                        citydt.Rows.Add(4, 14, "President Roxas");
                        citydt.Rows.Add(4, 15, "Roxas City (Capital)");
                        citydt.Rows.Add(4, 16, "Sapi-an");
                        citydt.Rows.Add(4, 17, "Sigma");
                        citydt.Rows.Add(4, 18, "Tapaz");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Buenavista");
                        citydt.Rows.Add(5, 3, "Jordan (Capital)");
                        citydt.Rows.Add(5, 4, "Nueva Valencia");
                        citydt.Rows.Add(5, 5, "San Lorenzo");
                        citydt.Rows.Add(5, 6, "Sibunag");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Iloilo City (Capital)");
                        citydt.Rows.Add(6, 3, "Passi City");
                        citydt.Rows.Add(6, 4, "Ajuy");
                        citydt.Rows.Add(6, 5, "Alimodian");
                        citydt.Rows.Add(6, 6, "Anilao");
                        citydt.Rows.Add(6, 7, "Badiangan");
                        citydt.Rows.Add(6, 8, "Balasan");
                        citydt.Rows.Add(6, 9, "Banate");
                        citydt.Rows.Add(6, 10, "Barotac Nuevo");
                        citydt.Rows.Add(6, 11, "Barotac Viejo");
                        citydt.Rows.Add(6, 12, "Batad");
                        citydt.Rows.Add(6, 13, "Bingawan");
                        citydt.Rows.Add(6, 14, "Cabatuan");
                        citydt.Rows.Add(6, 15, "Calinog");
                        citydt.Rows.Add(6, 16, "Carles");
                        citydt.Rows.Add(6, 17, "Concepcion");
                        citydt.Rows.Add(6, 18, "Dingle");
                        citydt.Rows.Add(6, 19, "Dueñas");
                        citydt.Rows.Add(6, 20, "Dumangas");
                        citydt.Rows.Add(6, 21, "Estancia");
                        citydt.Rows.Add(6, 22, "Guimbal");
                        citydt.Rows.Add(6, 23, "Igbaras");
                        citydt.Rows.Add(6, 24, "Janiuay");
                        citydt.Rows.Add(6, 25, "Lambunao");
                        citydt.Rows.Add(6, 26, "Leganes");
                        citydt.Rows.Add(6, 27, "Lemery");
                        citydt.Rows.Add(6, 28, "Leon");
                        citydt.Rows.Add(6, 29, "Maasin");
                        citydt.Rows.Add(6, 30, "Miagao");
                        citydt.Rows.Add(6, 31, "Mina");
                        citydt.Rows.Add(6, 32, "New Lucena");
                        citydt.Rows.Add(6, 33, "Oton");
                        citydt.Rows.Add(6, 34, "Pavia");
                        citydt.Rows.Add(6, 35, "Pototan");
                        citydt.Rows.Add(6, 36, "San Dionisio");
                        citydt.Rows.Add(6, 37, "San Enrique");
                        citydt.Rows.Add(6, 38, "San Joaquin");
                        citydt.Rows.Add(6, 39, "San Miguel");
                        citydt.Rows.Add(6, 40, "San Rafael");
                        citydt.Rows.Add(6, 41, "Santa Barbara");
                        citydt.Rows.Add(6, 42, "Sara");
                        citydt.Rows.Add(6, 43, "Tigbauan");
                        citydt.Rows.Add(6, 44, "Tubungan");
                        citydt.Rows.Add(6, 45, "Zarraga");
                    }
                    else if (province.SelectedValue == "7")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Bacolod City (Capital)");
                        citydt.Rows.Add(7, 3, "Bago City");
                        citydt.Rows.Add(7, 4, "Cadiz City");
                        citydt.Rows.Add(7, 5, "Escalante City");
                        citydt.Rows.Add(7, 6, "Himamaylan City");
                        citydt.Rows.Add(7, 7, "Kabankalan City");
                        citydt.Rows.Add(7, 8, "La Carlota City");
                        citydt.Rows.Add(7, 9, "Sagay City");
                        citydt.Rows.Add(7, 10, "San Carlos City");
                        citydt.Rows.Add(7, 11, "Silay City");
                        citydt.Rows.Add(7, 12, "Sipalay City");
                        citydt.Rows.Add(7, 13, "Talisay City");
                        citydt.Rows.Add(7, 14, "Victorias City");
                        citydt.Rows.Add(7, 15, "Binalbagan");
                        citydt.Rows.Add(7, 16, "Calatrava");
                        citydt.Rows.Add(7, 17, "Candoni");
                        citydt.Rows.Add(7, 18, "Cauayan");
                        citydt.Rows.Add(7, 19, "Enrique B. Magalona");
                        citydt.Rows.Add(7, 20, "Hinigaran");
                        citydt.Rows.Add(7, 21, "Hinoba-an");
                        citydt.Rows.Add(7, 22, "Ilog");
                        citydt.Rows.Add(7, 23, "Isabela");
                        citydt.Rows.Add(7, 24, "La Castellana");
                        citydt.Rows.Add(7, 25, "Manapla");
                        citydt.Rows.Add(7, 26, "Moises Padilla (Magallon)");
                        citydt.Rows.Add(7, 27, "Murcia");
                        citydt.Rows.Add(7, 28, "Pontevedra");
                        citydt.Rows.Add(7, 29, "Pulupandan");
                        citydt.Rows.Add(7, 30, "Salvador Benedicto");
                        citydt.Rows.Add(7, 31, "San Enrique");
                        citydt.Rows.Add(7, 32, "Toboso");
                        citydt.Rows.Add(7, 33, "Valladolid");
                    }
                }
                else if (region.SelectedValue == "9")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Alburquerque");
                        citydt.Rows.Add(2, 3, "Alicia");
                        citydt.Rows.Add(2, 4, "Anda");
                        citydt.Rows.Add(2, 5, "Antequera");
                        citydt.Rows.Add(2, 6, "Baclayon");
                        citydt.Rows.Add(2, 7, "Balilihan");
                        citydt.Rows.Add(2, 8, "Batuan");
                        citydt.Rows.Add(2, 9, "Bien Unido");
                        citydt.Rows.Add(2, 10, "Bilar");
                        citydt.Rows.Add(2, 11, "Buenavista");
                        citydt.Rows.Add(2, 12, "Calape");
                        citydt.Rows.Add(2, 13, "Candijay");
                        citydt.Rows.Add(2, 14, "Carmen");
                        citydt.Rows.Add(2, 15, "Catigbian");
                        citydt.Rows.Add(2, 16, "Clarin");
                        citydt.Rows.Add(2, 17, "Corella");
                        citydt.Rows.Add(2, 18, "Cortes");
                        citydt.Rows.Add(2, 19, "Dagohoy");
                        citydt.Rows.Add(2, 20, "Danao");
                        citydt.Rows.Add(2, 21, "Dauis");
                        citydt.Rows.Add(2, 22, "Dimiao");
                        citydt.Rows.Add(2, 23, "Duero");
                        citydt.Rows.Add(2, 24, "Garcia Hernandez");
                        citydt.Rows.Add(2, 25, "Guindulman");
                        citydt.Rows.Add(2, 26, "Inabanga");
                        citydt.Rows.Add(2, 27, "Jagna");
                        citydt.Rows.Add(2, 28, "Lila");
                        citydt.Rows.Add(2, 29, "Loay");
                        citydt.Rows.Add(2, 30, "Loboc");
                        citydt.Rows.Add(2, 31, "Loon");
                        citydt.Rows.Add(2, 32, "Mabini");
                        citydt.Rows.Add(2, 33, "Maribojoc");
                        citydt.Rows.Add(2, 34, "Panglao");
                        citydt.Rows.Add(2, 35, "Pilar");
                        citydt.Rows.Add(2, 36, "President Carlos P. Garcia (Pitogo)");
                        citydt.Rows.Add(2, 37, "Sagbayan (Borja)");
                        citydt.Rows.Add(2, 38, "San Isidro");
                        citydt.Rows.Add(2, 39, "San Miguel");
                        citydt.Rows.Add(2, 40, "Sevill");
                        citydt.Rows.Add(2, 41, "Sierra Bullones");
                        citydt.Rows.Add(2, 42, "Sikatuna");
                        citydt.Rows.Add(2, 43, "Tagbilaran City (Capital)");
                        citydt.Rows.Add(2, 44, "Talibon");
                        citydt.Rows.Add(2, 45, "Trinidad");
                        citydt.Rows.Add(2, 46, "Tubigon");
                        citydt.Rows.Add(2, 47, "Ubay");
                        citydt.Rows.Add(2, 48, "Valencia");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Cebu City (Capital)");
                        citydt.Rows.Add(3, 3, "Toledo City");
                        citydt.Rows.Add(3, 4, "Bogo City");
                        citydt.Rows.Add(3, 5, "Carcar City");
                        citydt.Rows.Add(3, 6, "Danao City");
                        citydt.Rows.Add(3, 7, "Lapu-Lapu City");
                        citydt.Rows.Add(3, 8, "Mandaue City");
                        citydt.Rows.Add(3, 9, "Naga City");
                        citydt.Rows.Add(3, 10, "Talisay City");
                        citydt.Rows.Add(3, 11, "Alcantara");
                        citydt.Rows.Add(3, 12, "Alcoy");
                        citydt.Rows.Add(3, 13, "Alegria");
                        citydt.Rows.Add(3, 14, "Aloguinsan");
                        citydt.Rows.Add(3, 15, "Argao");
                        citydt.Rows.Add(3, 16, "Asturias");
                        citydt.Rows.Add(3, 17, "Badian");
                        citydt.Rows.Add(3, 18, "Balamban");
                        citydt.Rows.Add(3, 19, "Bantayan");
                        citydt.Rows.Add(3, 20, "Barili");
                        citydt.Rows.Add(3, 21, "Boljoon");
                        citydt.Rows.Add(3, 22, "Borbon");
                        citydt.Rows.Add(3, 23, "Carmen");
                        citydt.Rows.Add(3, 24, "Catmon");
                        citydt.Rows.Add(3, 25, "Compostela");
                        citydt.Rows.Add(3, 26, "Consolacion");
                        citydt.Rows.Add(3, 27, "Cordova");
                        citydt.Rows.Add(3, 28, "Daanbantayan");
                        citydt.Rows.Add(3, 29, "Dalaguete");
                        citydt.Rows.Add(3, 30, "Dumanjug");
                        citydt.Rows.Add(3, 31, "Ginatilan");
                        citydt.Rows.Add(3, 32, "Liloan");
                        citydt.Rows.Add(3, 33, "Madridejos");
                        citydt.Rows.Add(3, 34, "Malabuyoc");
                        citydt.Rows.Add(3, 35, "Medellin");
                        citydt.Rows.Add(3, 36, "Minglanilla");
                        citydt.Rows.Add(3, 37, "Moalboal");
                        citydt.Rows.Add(3, 38, "Oslob");
                        citydt.Rows.Add(3, 39, "Pilar");
                        citydt.Rows.Add(3, 40, "Pinamungahan");
                        citydt.Rows.Add(3, 41, "Poro");
                        citydt.Rows.Add(3, 42, "Ronda");
                        citydt.Rows.Add(3, 43, "Samboan");
                        citydt.Rows.Add(3, 44, "San Fernando");
                        citydt.Rows.Add(3, 45, "San Francisco");
                        citydt.Rows.Add(3, 46, "San Remigio");
                        citydt.Rows.Add(3, 47, "Santa Fe");
                        citydt.Rows.Add(3, 48, "Santander");
                        citydt.Rows.Add(3, 49, "Sibonga");
                        citydt.Rows.Add(3, 50, "Sogod");
                        citydt.Rows.Add(3, 51, "Tabogon");
                        citydt.Rows.Add(3, 52, "Tabuelan");
                        citydt.Rows.Add(3, 53, "Tuburan");
                        citydt.Rows.Add(3, 54, "Tudela");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Dumaguete City (Capital)");
                        citydt.Rows.Add(4, 3, "Bais City");
                        citydt.Rows.Add(4, 4, "Bayawan City");
                        citydt.Rows.Add(4, 5, "Canlaon City");
                        citydt.Rows.Add(4, 6, "Guihulngan City");
                        citydt.Rows.Add(4, 7, "Tanjay City");
                        citydt.Rows.Add(4, 8, "Amlan");
                        citydt.Rows.Add(4, 9, "Ayungon");
                        citydt.Rows.Add(4, 10, "Bacong");
                        citydt.Rows.Add(4, 11, "Basay");
                        citydt.Rows.Add(4, 12, "Bindoy");
                        citydt.Rows.Add(4, 13, "Dauin");
                        citydt.Rows.Add(4, 14, "Jimalalud");
                        citydt.Rows.Add(4, 15, "La Libertad");
                        citydt.Rows.Add(4, 16, "Mabinay");
                        citydt.Rows.Add(4, 17, "Manjuyod");
                        citydt.Rows.Add(4, 18, "Pamplona");
                        citydt.Rows.Add(4, 19, "San Jose");
                        citydt.Rows.Add(4, 20, "Santa Catalina");
                        citydt.Rows.Add(4, 21, "Siaton");
                        citydt.Rows.Add(4, 22, "Sibulan");
                        citydt.Rows.Add(4, 23, "Tayasan");
                        citydt.Rows.Add(4, 24, "Valencia");
                        citydt.Rows.Add(4, 25, "Vallehermoso");
                        citydt.Rows.Add(4, 26, "Zamboanguita");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Enrique Villanueva");
                        citydt.Rows.Add(5, 3, "Larena");
                        citydt.Rows.Add(5, 4, "Lazi");
                        citydt.Rows.Add(5, 5, "Maria");
                        citydt.Rows.Add(5, 6, "San Juan");
                        citydt.Rows.Add(5, 7, "Siquijor (Capital)");
                    }
                }
                else if (region.SelectedValue == "10")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Almeria");
                        citydt.Rows.Add(2, 3, "Biliran");
                        citydt.Rows.Add(2, 4, "Cabucgayan");
                        citydt.Rows.Add(2, 5, "Caibiran");
                        citydt.Rows.Add(2, 6, "Culaba");
                        citydt.Rows.Add(2, 7, "Kawayan");
                        citydt.Rows.Add(2, 8, "Maripipi");
                        citydt.Rows.Add(2, 9, "Naval (Capital)");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Arteche");
                        citydt.Rows.Add(3, 3, "Balangiga");
                        citydt.Rows.Add(3, 4, "Balangkayan");
                        citydt.Rows.Add(3, 5, "Borongan (Capital)");
                        citydt.Rows.Add(3, 6, "Can-avid");
                        citydt.Rows.Add(3, 7, "Dolores");
                        citydt.Rows.Add(3, 8, "General MacArthur");
                        citydt.Rows.Add(3, 9, "Giporlos");
                        citydt.Rows.Add(3, 10, "Guiuan");
                        citydt.Rows.Add(3, 11, "Hernani");
                        citydt.Rows.Add(3, 12, "Jipapad");
                        citydt.Rows.Add(3, 13, "Lawaan");
                        citydt.Rows.Add(3, 14, "Llorente");
                        citydt.Rows.Add(3, 15, "Maslog");
                        citydt.Rows.Add(3, 16, "Maydolong");
                        citydt.Rows.Add(3, 17, "Mercedes");
                        citydt.Rows.Add(3, 18, "Oras");
                        citydt.Rows.Add(3, 19, "Quinapondan");
                        citydt.Rows.Add(3, 20, "Salcedo");
                        citydt.Rows.Add(3, 21, "San Julian");
                        citydt.Rows.Add(3, 22, "San Policarpo");
                        citydt.Rows.Add(3, 23, "Sulat");
                        citydt.Rows.Add(3, 24, "Taft");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Tacloban City (Capital)");
                        citydt.Rows.Add(4, 3, "Ormoc City");
                        citydt.Rows.Add(4, 4, "Baybay City");
                        citydt.Rows.Add(4, 5, "Abuyog");
                        citydt.Rows.Add(4, 6, "Alangalang");
                        citydt.Rows.Add(4, 7, "Albuera");
                        citydt.Rows.Add(4, 8, "Babatngon");
                        citydt.Rows.Add(4, 9, "Barugo");
                        citydt.Rows.Add(4, 10, "Bato");
                        citydt.Rows.Add(4, 11, "Burauen");
                        citydt.Rows.Add(4, 12, "Calubian");
                        citydt.Rows.Add(4, 13, "Capoocan");
                        citydt.Rows.Add(4, 14, "Carigara");
                        citydt.Rows.Add(4, 15, "Dagami");
                        citydt.Rows.Add(4, 16, "Dulag");
                        citydt.Rows.Add(4, 17, "Hilongos");
                        citydt.Rows.Add(4, 18, "Hindang");
                        citydt.Rows.Add(4, 19, "Inopacan");
                        citydt.Rows.Add(4, 20, "Isabel");
                        citydt.Rows.Add(4, 21, "Jaro");
                        citydt.Rows.Add(4, 22, "Javier (Bugho)");
                        citydt.Rows.Add(4, 23, "Julita");
                        citydt.Rows.Add(4, 24, "Kananga");
                        citydt.Rows.Add(4, 25, "La Paz");
                        citydt.Rows.Add(4, 26, "Leyte");
                        citydt.Rows.Add(4, 27, "MacArthur");
                        citydt.Rows.Add(4, 28, "Mahaplag");
                        citydt.Rows.Add(4, 29, "Matag-ob");
                        citydt.Rows.Add(4, 30, "Matalom");
                        citydt.Rows.Add(4, 31, "Mayorga");
                        citydt.Rows.Add(4, 32, "Merida");
                        citydt.Rows.Add(4, 33, "Palo");
                        citydt.Rows.Add(4, 34, "Palompon");
                        citydt.Rows.Add(4, 35, "Pastrana");
                        citydt.Rows.Add(4, 36, "San Isidro");
                        citydt.Rows.Add(4, 37, "San Miguel");
                        citydt.Rows.Add(4, 38, "Santa Fe");
                        citydt.Rows.Add(4, 39, "Tabango");
                        citydt.Rows.Add(4, 40, "Tabontabon");
                        citydt.Rows.Add(4, 41, "Tanauan");
                        citydt.Rows.Add(4, 42, "Tolosa");
                        citydt.Rows.Add(4, 43, "Tunga");
                        citydt.Rows.Add(4, 44, "Villaba");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Allen");
                        citydt.Rows.Add(5, 3, "Biri");
                        citydt.Rows.Add(5, 4, "Bobon");
                        citydt.Rows.Add(5, 5, "Capul");
                        citydt.Rows.Add(5, 6, "Catarman (Capital)");
                        citydt.Rows.Add(5, 7, "Catubig");
                        citydt.Rows.Add(5, 8, "Gamay");
                        citydt.Rows.Add(5, 9, "Laoang");
                        citydt.Rows.Add(5, 10, "Lapinig");
                        citydt.Rows.Add(5, 11, "Las Navas");
                        citydt.Rows.Add(5, 12, "Lavezares");
                        citydt.Rows.Add(5, 13, "Lope de Vega");
                        citydt.Rows.Add(5, 14, "Mapanas");
                        citydt.Rows.Add(5, 15, "Mondragon");
                        citydt.Rows.Add(5, 16, "Palapag");
                        citydt.Rows.Add(5, 17, "Pambujan");
                        citydt.Rows.Add(5, 18, "Rosario");
                        citydt.Rows.Add(5, 19, "San Antonio");
                        citydt.Rows.Add(5, 20, "San Isidro");
                        citydt.Rows.Add(5, 21, "San Jose");
                        citydt.Rows.Add(5, 22, "San Roque");
                        citydt.Rows.Add(5, 23, "San Vicente");
                        citydt.Rows.Add(5, 24, "Silvino Lobos");
                        citydt.Rows.Add(5, 25, "Victoria");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Almagro");
                        citydt.Rows.Add(6, 3, "Basey");
                        citydt.Rows.Add(6, 4, "Calbayog City");
                        citydt.Rows.Add(6, 5, "Calbiga");
                        citydt.Rows.Add(6, 6, "Catbalogan City (Capital)");
                        citydt.Rows.Add(6, 7, "Daram");
                        citydt.Rows.Add(6, 8, "Gandara");
                        citydt.Rows.Add(6, 9, "Hinabangan");
                        citydt.Rows.Add(6, 10, "Jiabong");
                        citydt.Rows.Add(6, 11, "Marabut");
                        citydt.Rows.Add(6, 12, "Matuguinao");
                        citydt.Rows.Add(6, 13, "Motiong");
                        citydt.Rows.Add(6, 14, "Pagsanghan");
                        citydt.Rows.Add(6, 15, "Paranas (Wright)");
                        citydt.Rows.Add(6, 16, "Pinabacdao");
                        citydt.Rows.Add(6, 17, "San Jorge");
                        citydt.Rows.Add(6, 18, "San Jose de Buan");
                        citydt.Rows.Add(6, 19, "San Sebastian");
                        citydt.Rows.Add(6, 20, "Santa Margarita");
                        citydt.Rows.Add(6, 21, "Santa Rita");
                        citydt.Rows.Add(6, 22, "Santo Niño");
                        citydt.Rows.Add(6, 23, "Tagapul-an");
                        citydt.Rows.Add(6, 24, "Talalora");
                        citydt.Rows.Add(6, 25, "Tarangnan");
                        citydt.Rows.Add(6, 26, "Villareal");
                        citydt.Rows.Add(6, 27, "Zumarraga");
                    }
                    else if (province.SelectedValue == "7")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Anahawan");
                        citydt.Rows.Add(7, 3, "Bontoc");
                        citydt.Rows.Add(7, 4, "Hinunangan");
                        citydt.Rows.Add(7, 5, "Hinundayan");
                        citydt.Rows.Add(7, 6, "Libagon");
                        citydt.Rows.Add(7, 7, "Liloan");
                        citydt.Rows.Add(7, 8, "Limasawa");
                        citydt.Rows.Add(7, 9, "Macrohon");
                        citydt.Rows.Add(7, 10, "Malitbog");
                        citydt.Rows.Add(7, 11, "Padre Burgos");
                        citydt.Rows.Add(7, 12, "Pintuyan");
                        citydt.Rows.Add(7, 13, "Saint Bernard");
                        citydt.Rows.Add(7, 14, "San Francisco");
                        citydt.Rows.Add(7, 15, "San Juan (Cabalian)");
                        citydt.Rows.Add(7, 16, "San Ricardo");
                        citydt.Rows.Add(7, 17, "Silago");
                        citydt.Rows.Add(7, 18, "Sogod (Capital)");
                        citydt.Rows.Add(7, 19, "Tomas Oppus");
                    }
                }
                else if (region.SelectedValue == "11")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Dapitan City");
                        citydt.Rows.Add(2, 3, "Dipolog City (Capital)");
                        citydt.Rows.Add(2, 4, "Bacungan");
                        citydt.Rows.Add(2, 5, "Baliguian");
                        citydt.Rows.Add(2, 6, "Godod");
                        citydt.Rows.Add(2, 7, "Gutalac");
                        citydt.Rows.Add(2, 8, "Jose Dalman (Ponot)");
                        citydt.Rows.Add(2, 9, "Kalawit");
                        citydt.Rows.Add(2, 10, "Katipunan");
                        citydt.Rows.Add(2, 11, "La Libertad");
                        citydt.Rows.Add(2, 12, "Labason");
                        citydt.Rows.Add(2, 13, "Liloy");
                        citydt.Rows.Add(2, 14, "Manukan");
                        citydt.Rows.Add(2, 15, "Mutia");
                        citydt.Rows.Add(2, 16, "Piñan");
                        citydt.Rows.Add(2, 17, "Polanco");
                        citydt.Rows.Add(2, 18, "President Manuel A. Roxas");
                        citydt.Rows.Add(2, 19, "Rizal");
                        citydt.Rows.Add(2, 20, "Salug");
                        citydt.Rows.Add(2, 21, "Sergio Osmeña Sr.");
                        citydt.Rows.Add(2, 22, "Siayan");
                        citydt.Rows.Add(2, 23, "Sibuco");
                        citydt.Rows.Add(2, 24, "Sindangan");
                        citydt.Rows.Add(2, 25, "Siocon");
                        citydt.Rows.Add(2, 26, "Sirawai");
                        citydt.Rows.Add(2, 27, "Tampilisan");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Pagadian City (Capital)");
                        citydt.Rows.Add(3, 3, "Dinas");
                        citydt.Rows.Add(3, 4, "Dumalinao");
                        citydt.Rows.Add(3, 5, "Dumingag");
                        citydt.Rows.Add(3, 6, "Guipos");
                        citydt.Rows.Add(3, 7, "Josefina");
                        citydt.Rows.Add(3, 8, "Kumalarang");
                        citydt.Rows.Add(3, 9, "Labangan");
                        citydt.Rows.Add(3, 10, "Lakewood");
                        citydt.Rows.Add(3, 11, "Lapuyan");
                        citydt.Rows.Add(3, 12, "Mahayag");
                        citydt.Rows.Add(3, 13, "Margosatubig");
                        citydt.Rows.Add(3, 14, "Midsalip");
                        citydt.Rows.Add(3, 15, "Molave");
                        citydt.Rows.Add(3, 16, "Pitogo");
                        citydt.Rows.Add(3, 17, "Ramon Magsaysay (Liargo)");
                        citydt.Rows.Add(3, 18, "San Miguel");
                        citydt.Rows.Add(3, 19, "San Pablo");
                        citydt.Rows.Add(3, 20, "Sominot");
                        citydt.Rows.Add(3, 21, "Tabina");
                        citydt.Rows.Add(3, 22, "Tambulig");
                        citydt.Rows.Add(3, 23, "Tigbao");
                        citydt.Rows.Add(3, 24, "Tukuran");
                        citydt.Rows.Add(3, 25, "Vincenzo A. Sagun");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Ipil (Capital)");
                        citydt.Rows.Add(4, 3, "Alicia");
                        citydt.Rows.Add(4, 4, "Buug");
                        citydt.Rows.Add(4, 5, "Diplahan");
                        citydt.Rows.Add(4, 6, "Imelda");
                        citydt.Rows.Add(4, 7, "Kabasalan");
                        citydt.Rows.Add(4, 8, "Mabuhay");
                        citydt.Rows.Add(4, 9, "Malangas");
                        citydt.Rows.Add(4, 10, "Naga");
                        citydt.Rows.Add(4, 11, "Olutanga");
                        citydt.Rows.Add(4, 12, "Payao");
                        citydt.Rows.Add(4, 13, "Roseller T. Lim");
                        citydt.Rows.Add(4, 14, "Siay");
                        citydt.Rows.Add(4, 15, "Talusan");
                        citydt.Rows.Add(4, 16, "Titay");
                        citydt.Rows.Add(4, 17, "Tungawan");
                    }
                }
                else if (region.SelectedValue == "12")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Malaybalay City (Capital)");
                        citydt.Rows.Add(2, 3, "Valencia City");
                        citydt.Rows.Add(2, 4, "Baungon");
                        citydt.Rows.Add(2, 5, "Cabanglasan");
                        citydt.Rows.Add(2, 6, "Damulog");
                        citydt.Rows.Add(2, 7, "Dangcagan");
                        citydt.Rows.Add(2, 8, "Don Carlos");
                        citydt.Rows.Add(2, 9, "Impasugong");
                        citydt.Rows.Add(2, 10, "Kadingilan");
                        citydt.Rows.Add(2, 11, "Kalilangan");
                        citydt.Rows.Add(2, 12, "Kibawe");
                        citydt.Rows.Add(2, 13, "Kitaotao");
                        citydt.Rows.Add(2, 14, "Lantapan");
                        citydt.Rows.Add(2, 15, "Libona");
                        citydt.Rows.Add(2, 16, "Malitbog");
                        citydt.Rows.Add(2, 17, "Manolo Fortich");
                        citydt.Rows.Add(2, 18, "Maramag");
                        citydt.Rows.Add(2, 19, "Pangantucan");
                        citydt.Rows.Add(2, 20, "Quezon");
                        citydt.Rows.Add(2, 21, "San Fernando");
                        citydt.Rows.Add(2, 22, "Sumilao");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Catarman");
                        citydt.Rows.Add(3, 3, "Guinsiliban");
                        citydt.Rows.Add(3, 4, "Mahinog");
                        citydt.Rows.Add(3, 5, "Mambajao (Capital)");
                        citydt.Rows.Add(3, 6, "Sagay");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Iligan City");
                        citydt.Rows.Add(4, 3, "Bacolod");
                        citydt.Rows.Add(4, 4, "Baloi");
                        citydt.Rows.Add(4, 5, "Baroy");
                        citydt.Rows.Add(4, 6, "Kapatagan");
                        citydt.Rows.Add(4, 7, "Kauswagan");
                        citydt.Rows.Add(4, 8, "Kolambugan");
                        citydt.Rows.Add(4, 9, "Lala");
                        citydt.Rows.Add(4, 10, "Linamon");
                        citydt.Rows.Add(4, 11, "Magsaysay");
                        citydt.Rows.Add(4, 12, "Maigo");
                        citydt.Rows.Add(4, 13, "Matungao");
                        citydt.Rows.Add(4, 14, "Munai");
                        citydt.Rows.Add(4, 15, "Nunungan");
                        citydt.Rows.Add(4, 16, "Pantao Ragat");
                        citydt.Rows.Add(4, 17, "Pantar");
                        citydt.Rows.Add(4, 18, "Poona Piagapo");
                        citydt.Rows.Add(4, 19, "Salvador");
                        citydt.Rows.Add(4, 20, "Sapad");
                        citydt.Rows.Add(4, 21, "Sultan Naga Dimaporo (Karomatan)");
                        citydt.Rows.Add(4, 22, "Tagoloan");
                        citydt.Rows.Add(4, 23, "Tangcal");
                        citydt.Rows.Add(4, 24, "Tubod (Capital)");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Oroquieta City (Capital)");
                        citydt.Rows.Add(5, 3, "Ozamiz City");
                        citydt.Rows.Add(5, 4, "Tangub City");
                        citydt.Rows.Add(5, 5, "Aloran");
                        citydt.Rows.Add(5, 6, "Baliangao");
                        citydt.Rows.Add(5, 7, "Bonifacio");
                        citydt.Rows.Add(5, 8, "Calamba");
                        citydt.Rows.Add(5, 9, "Clarin");
                        citydt.Rows.Add(5, 10, "Concepcion");
                        citydt.Rows.Add(5, 11, "Don Victoriano Chiongbian");
                        citydt.Rows.Add(5, 12, "Jimenez");
                        citydt.Rows.Add(5, 13, "Lopez Jaena");
                        citydt.Rows.Add(5, 14, "Panaon");
                        citydt.Rows.Add(5, 15, "Plaridel");
                        citydt.Rows.Add(5, 16, "Sapang Dalaga");
                        citydt.Rows.Add(5, 17, "Sinacaban");
                        citydt.Rows.Add(5, 18, "Tudela");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Cagayan de Oro City (Capital)");
                        citydt.Rows.Add(6, 3, "El Salvador City");
                        citydt.Rows.Add(6, 4, "Gingoog City");
                        citydt.Rows.Add(6, 5, "Alubijid");
                        citydt.Rows.Add(6, 6, "Balingasag");
                        citydt.Rows.Add(6, 7, "Balingoan");
                        citydt.Rows.Add(6, 8, "Binuangan");
                        citydt.Rows.Add(6, 9, "Claveria");
                        citydt.Rows.Add(6, 10, "Gitagum");
                        citydt.Rows.Add(6, 11, "Initao");
                        citydt.Rows.Add(6, 12, "Jasaan");
                        citydt.Rows.Add(6, 13, "Kinoguitan");
                        citydt.Rows.Add(6, 14, "Lagonglong");
                        citydt.Rows.Add(6, 15, "Laguindingan");
                        citydt.Rows.Add(6, 16, "Libertad");
                        citydt.Rows.Add(6, 17, "Lugait");
                        citydt.Rows.Add(6, 18, "Magsaysay");
                        citydt.Rows.Add(6, 19, "Manticao");
                        citydt.Rows.Add(6, 20, "Medina");
                        citydt.Rows.Add(6, 21, "Naawan");
                        citydt.Rows.Add(6, 22, "Opol");
                        citydt.Rows.Add(6, 23, "Salay");
                        citydt.Rows.Add(6, 24, "Sugbongcogon");
                        citydt.Rows.Add(6, 25, "Tagoloan");
                        citydt.Rows.Add(6, 26, "Talisayan");
                        citydt.Rows.Add(6, 27, "Villanueva");
                    }
                }
                else if (region.SelectedValue == "13")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Tagum City (Capital)");
                        citydt.Rows.Add(2, 3, "Panabo City");
                        citydt.Rows.Add(2, 4, "Island Garden City of Samal");
                        citydt.Rows.Add(2, 5, "Asuncion (Saug)");
                        citydt.Rows.Add(2, 6, "Braulio E. Dujali");
                        citydt.Rows.Add(2, 7, "Carmen");
                        citydt.Rows.Add(2, 8, "Kapalong");
                        citydt.Rows.Add(2, 9, "New Corella");
                        citydt.Rows.Add(2, 10, "San Isidro");
                        citydt.Rows.Add(2, 11, "Santo Tomas");
                        citydt.Rows.Add(2, 12, "Talaingod");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Digos City (Capital)");
                        citydt.Rows.Add(3, 3, "Bansalan");
                        citydt.Rows.Add(3, 4, "Don Marcelino");
                        citydt.Rows.Add(3, 5, "Hagonoy");
                        citydt.Rows.Add(3, 6, "Jose Abad Santos (Trinidad)");
                        citydt.Rows.Add(3, 7, "Kiblawan");
                        citydt.Rows.Add(3, 8, "Magsaysay");
                        citydt.Rows.Add(3, 9, "Malalag");
                        citydt.Rows.Add(3, 10, "Matanao");
                        citydt.Rows.Add(3, 11, "Padada");
                        citydt.Rows.Add(3, 12, "Santa Cruz");
                        citydt.Rows.Add(3, 13, "Sulop");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Don Marcelino");
                        citydt.Rows.Add(4, 3, "Jose Abad Santos (Trinidad)");
                        citydt.Rows.Add(4, 4, "Malita (Capital)");
                        citydt.Rows.Add(4, 5, "Santa Maria");
                        citydt.Rows.Add(4, 6, "Sarangani");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Mati City (Capital)");
                        citydt.Rows.Add(5, 3, "Baganga");
                        citydt.Rows.Add(5, 4, "Banaybanay");
                        citydt.Rows.Add(5, 5, "Boston");
                        citydt.Rows.Add(5, 6, "Caraga");
                        citydt.Rows.Add(5, 7, "Cateel");
                        citydt.Rows.Add(5, 8, "Governor Generoso");
                        citydt.Rows.Add(5, 9, "Lupon");
                        citydt.Rows.Add(5, 10, "Manay");
                        citydt.Rows.Add(5, 11, "San Isidro");
                        citydt.Rows.Add(5, 12, "Tarragona");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Compostela");
                        citydt.Rows.Add(6, 3, "Laak");
                        citydt.Rows.Add(6, 4, "Mabini");
                        citydt.Rows.Add(6, 5, "Maco");
                        citydt.Rows.Add(6, 6, "Maragusan");
                        citydt.Rows.Add(6, 7, "Mawab");
                        citydt.Rows.Add(6, 8, "Monkayo");
                        citydt.Rows.Add(6, 9, "Montevista");
                        citydt.Rows.Add(6, 10, "Nabunturan");
                        citydt.Rows.Add(6, 11, "New Bataan");
                        citydt.Rows.Add(6, 12, "Pantukan");
                    }
                }
                else if (region.SelectedValue == "14")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Kidapawan City (Capital)");
                        citydt.Rows.Add(2, 3, "Alamada");
                        citydt.Rows.Add(2, 4, "Aleosan");
                        citydt.Rows.Add(2, 5, "Antipas");
                        citydt.Rows.Add(2, 6, "Arakan");
                        citydt.Rows.Add(2, 7, "Banisilan");
                        citydt.Rows.Add(2, 8, "Carmen");
                        citydt.Rows.Add(2, 9, "Kabacan");
                        citydt.Rows.Add(2, 10, "Libungan");
                        citydt.Rows.Add(2, 11, "Magpet");
                        citydt.Rows.Add(2, 12, "Makilala");
                        citydt.Rows.Add(2, 13, "Matalam");
                        citydt.Rows.Add(2, 14, "M'lang");
                        citydt.Rows.Add(2, 15, "Pigcawayan");
                        citydt.Rows.Add(2, 16, "Pikit");
                        citydt.Rows.Add(2, 17, "President Roxas");
                        citydt.Rows.Add(2, 18, "Tulunan");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Alabel (Capital)");
                        citydt.Rows.Add(3, 3, "Glan");
                        citydt.Rows.Add(3, 4, "Kiamba");
                        citydt.Rows.Add(3, 5, "Maasim");
                        citydt.Rows.Add(3, 6, "Maitum");
                        citydt.Rows.Add(3, 7, "Malapatan");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "General Santos City");
                        citydt.Rows.Add(4, 3, "Koronadal City (Capital)");
                        citydt.Rows.Add(4, 4, "Banga");
                        citydt.Rows.Add(4, 5, "Lake Sebu");
                        citydt.Rows.Add(4, 6, "Norala");
                        citydt.Rows.Add(4, 7, "Polomolok");
                        citydt.Rows.Add(4, 8, "Santo Niño");
                        citydt.Rows.Add(4, 9, "Surallah");
                        citydt.Rows.Add(4, 10, "T'boli");
                        citydt.Rows.Add(4, 11, "Tampakan");
                        citydt.Rows.Add(4, 12, "Tantangan");
                        citydt.Rows.Add(4, 13, "Tupi");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Isulan (Capital)");
                        citydt.Rows.Add(5, 3, "Bagumbayan");
                        citydt.Rows.Add(5, 4, "Columbio");
                        citydt.Rows.Add(5, 5, "Esperanza");
                        citydt.Rows.Add(5, 6, "Kalamansig");
                        citydt.Rows.Add(5, 7, "Lambayong (Mariano Marcos)");
                        citydt.Rows.Add(5, 8, "Lebak");
                        citydt.Rows.Add(5, 9, "Lutayan");
                        citydt.Rows.Add(5, 10, "Palimbang");
                        citydt.Rows.Add(5, 11, "President Quirino");
                        citydt.Rows.Add(5, 12, "Senator Ninoy Aquino");
                    }
                }
                else if (region.SelectedValue == "15")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Butuan City (Capital)");
                        citydt.Rows.Add(2, 3, "Buenavista");
                        citydt.Rows.Add(2, 4, "Cabadbaran City");
                        citydt.Rows.Add(2, 5, "Carmen");
                        citydt.Rows.Add(2, 6, "Jabonga");
                        citydt.Rows.Add(2, 7, "Kitcharao");
                        citydt.Rows.Add(2, 8, "Las Nieves");
                        citydt.Rows.Add(2, 9, "Magallanes");
                        citydt.Rows.Add(2, 10, "Nasipit");
                        citydt.Rows.Add(2, 11, "Remedios T. Romualdez (La Paz)");
                        citydt.Rows.Add(2, 12, "Santiago");
                        citydt.Rows.Add(2, 13, "Tubay");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Bayugan City");
                        citydt.Rows.Add(3, 3, "Bislig City");
                        citydt.Rows.Add(3, 4, "Bunawan");
                        citydt.Rows.Add(3, 5, "Esperanza");
                        citydt.Rows.Add(3, 6, "La Paz");
                        citydt.Rows.Add(3, 7, "Loreto");
                        citydt.Rows.Add(3, 8, "Prosperidad (Capital)");
                        citydt.Rows.Add(3, 9, "Rosario");
                        citydt.Rows.Add(3, 10, "San Francisco");
                        citydt.Rows.Add(3, 11, "San Luis");
                        citydt.Rows.Add(3, 12, "Santa Josefa");
                        citydt.Rows.Add(3, 13, "Sibagat");
                        citydt.Rows.Add(3, 14, "Talacogon");
                        citydt.Rows.Add(3, 15, "Trento");
                        citydt.Rows.Add(3, 16, "Veruela");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Basilisa (Rizal)");
                        citydt.Rows.Add(4, 3, "Cagdianao");
                        citydt.Rows.Add(4, 4, "Dinagat");
                        citydt.Rows.Add(4, 5, "Libjo (Albor)");
                        citydt.Rows.Add(4, 6, "Loreto");
                        citydt.Rows.Add(4, 7, "San Jose (Capital)");
                        citydt.Rows.Add(4, 8, "Tubajon");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Surigao City (Capital)");
                        citydt.Rows.Add(5, 3, "Alegria");
                        citydt.Rows.Add(5, 4, "Bacuag");
                        citydt.Rows.Add(5, 5, "Burgos");
                        citydt.Rows.Add(5, 6, "Claver");
                        citydt.Rows.Add(5, 7, "Dapa");
                        citydt.Rows.Add(5, 8, "Del Carmen");
                        citydt.Rows.Add(5, 9, "General Luna");
                        citydt.Rows.Add(5, 10, "Gigaquit");
                        citydt.Rows.Add(5, 11, "Mainit");
                        citydt.Rows.Add(5, 12, "Malimono");
                        citydt.Rows.Add(5, 13, "Pilar");
                        citydt.Rows.Add(5, 14, "Placer");
                        citydt.Rows.Add(5, 15, "San Benito");
                        citydt.Rows.Add(5, 16, "San Francisco");
                        citydt.Rows.Add(5, 17, "San Isidro");
                        citydt.Rows.Add(5, 18, "Santa Monica");
                        citydt.Rows.Add(5, 19, "Sison");
                        citydt.Rows.Add(5, 20, "Socorro");
                        citydt.Rows.Add(5, 21, "Tagana-an");
                        citydt.Rows.Add(5, 22, "Tubod");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Tandag City (Capital)");
                        citydt.Rows.Add(6, 3, "Barobo");
                        citydt.Rows.Add(6, 4, "Bayabas");
                        citydt.Rows.Add(6, 5, "Bislig City");
                        citydt.Rows.Add(6, 6, "Carmen");
                        citydt.Rows.Add(6, 7, "Carrascal");
                        citydt.Rows.Add(6, 8, "Cantilan");
                        citydt.Rows.Add(6, 9, "Cortes");
                        citydt.Rows.Add(6, 10, "Hinatuan");
                        citydt.Rows.Add(6, 11, "Lanuza");
                        citydt.Rows.Add(6, 12, "Lianga");
                        citydt.Rows.Add(6, 13, "Lingig");
                        citydt.Rows.Add(6, 14, "Madrid");
                        citydt.Rows.Add(6, 15, "Marihatag");
                        citydt.Rows.Add(6, 16, "San Agustin");
                        citydt.Rows.Add(6, 17, "San Miguel");
                        citydt.Rows.Add(6, 18, "Tagbina");
                        citydt.Rows.Add(6, 19, "Tago");
                    }
                }
                else if (region.SelectedValue == "16")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "City of Manila");
                        citydt.Rows.Add(2, 3, "Caloocan City");
                        citydt.Rows.Add(2, 4, "Las Piñas City");
                        citydt.Rows.Add(2, 5, "Makati City");
                        citydt.Rows.Add(2, 6, "Malabon City");
                        citydt.Rows.Add(2, 7, "Mandaluyong City");
                        citydt.Rows.Add(2, 8, "Marikina City");
                        citydt.Rows.Add(2, 9, "Muntinlupa City");
                        citydt.Rows.Add(2, 10, "Navotas City");
                        citydt.Rows.Add(2, 11, "Parañaque City");
                        citydt.Rows.Add(2, 12, "Pasay City");
                        citydt.Rows.Add(2, 13, "Pasig City");
                        citydt.Rows.Add(2, 14, "Quezon City");
                        citydt.Rows.Add(2, 15, "San Juan City");
                        citydt.Rows.Add(2, 16, "Taguig City");
                        citydt.Rows.Add(2, 17, "Valenzuela City");
                    }                  
                }
                else if (region.SelectedValue == "17")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Bangued (Capital)");
                        citydt.Rows.Add(2, 3, "Boliney");
                        citydt.Rows.Add(2, 4, "Bucay");
                        citydt.Rows.Add(2, 5, "Bucloc");
                        citydt.Rows.Add(2, 6, "Daguioman");
                        citydt.Rows.Add(2, 7, "Danglas");
                        citydt.Rows.Add(2, 8, "Dolores");
                        citydt.Rows.Add(2, 9, "La Paz");
                        citydt.Rows.Add(2, 10, "Lacub");
                        citydt.Rows.Add(2, 11, "Lagangilang");
                        citydt.Rows.Add(2, 12, "Lagayan");
                        citydt.Rows.Add(2, 13, "Langiden");
                        citydt.Rows.Add(2, 14, "Licuan-Baay");
                        citydt.Rows.Add(2, 15, "Luba");
                        citydt.Rows.Add(2, 16, "Malibcong");
                        citydt.Rows.Add(2, 17, "Manabo");
                        citydt.Rows.Add(2, 18, "Penarrubia");
                        citydt.Rows.Add(2, 19, "Pidigan");
                        citydt.Rows.Add(2, 20, "Pilar");
                        citydt.Rows.Add(2, 21, "Sallapadan");
                        citydt.Rows.Add(2, 22, "San Isidro");
                        citydt.Rows.Add(2, 23, "San Juan");
                        citydt.Rows.Add(2, 24, "San Quintin");
                        citydt.Rows.Add(2, 25, "Tayum");
                        citydt.Rows.Add(2, 26, "Tineg");
                        citydt.Rows.Add(2, 27, "Tubo");
                        citydt.Rows.Add(2, 28, "Villaviciosa");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Calanasan (Bayag)");
                        citydt.Rows.Add(3, 3, "Conner");
                        citydt.Rows.Add(3, 4, "Flora");
                        citydt.Rows.Add(3, 5, "Kabugao (Capital)");
                        citydt.Rows.Add(3, 6, "Luna");
                        citydt.Rows.Add(3, 7, "Pudtol");
                        citydt.Rows.Add(3, 8, "Santa Marcela");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Baguio City (Capital)");
                        citydt.Rows.Add(4, 3, "Atok");
                        citydt.Rows.Add(4, 4, "Bakun");
                        citydt.Rows.Add(4, 5, "Bokod");
                        citydt.Rows.Add(4, 6, "Buguias");
                        citydt.Rows.Add(4, 7, "Itogon");
                        citydt.Rows.Add(4, 8, "Kabayan");
                        citydt.Rows.Add(4, 9, "Kapangan");
                        citydt.Rows.Add(4, 10, "Kibungan");
                        citydt.Rows.Add(4, 11, "La Trinidad");
                        citydt.Rows.Add(4, 12, "Mankayan");
                        citydt.Rows.Add(4, 13, "Sablan");
                        citydt.Rows.Add(4, 14, "Tuba");
                        citydt.Rows.Add(4, 15, "Tublay");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Lagawe (Capital)");
                        citydt.Rows.Add(5, 3, "Aguinaldo");
                        citydt.Rows.Add(5, 4, "Alfonso Lista (Potia)");
                        citydt.Rows.Add(5, 5, "Asipulo");
                        citydt.Rows.Add(5, 6, "Banaue");
                        citydt.Rows.Add(5, 7, "Hingyon");
                        citydt.Rows.Add(5, 8, "Hungduan");
                        citydt.Rows.Add(5, 9, "Kiangan");
                        citydt.Rows.Add(5, 10, "Lamut");
                        citydt.Rows.Add(5, 11, "Mayoyao");
                        citydt.Rows.Add(5, 12, "Tinoc");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Tabuk City (Capital)");
                        citydt.Rows.Add(6, 3, "Balbalan");
                        citydt.Rows.Add(6, 4, "Lubuagan");
                        citydt.Rows.Add(6, 5, "Pasil");
                        citydt.Rows.Add(6, 6, "Pinukpuk");
                        citydt.Rows.Add(6, 7, "Rizal (Liwan)");
                        citydt.Rows.Add(6, 8, "Tanudan");
                        citydt.Rows.Add(6, 9, "Tinglayan");
                    }
                    else if (province.SelectedValue == "7")
                    {
                        citydt.Rows.Add(7, 1, "Select");
                        citydt.Rows.Add(7, 2, "Bontoc (Capital)");
                        citydt.Rows.Add(7, 3, "Barlig");
                        citydt.Rows.Add(7, 4, "Bauko");
                        citydt.Rows.Add(7, 5, "Besao");
                        citydt.Rows.Add(7, 6, "Bontoc");
                        citydt.Rows.Add(7, 7, "Natonin");
                        citydt.Rows.Add(7, 8, "Paracelis");
                        citydt.Rows.Add(7, 9, "Sabangan");
                        citydt.Rows.Add(7, 10, "Sadanga");
                        citydt.Rows.Add(7, 11, "Sagada");
                        citydt.Rows.Add(7, 12, "Tadian");
                    }
                }
                else if (region.SelectedValue == "18")
                {
                    if (province.SelectedValue == "2")
                    {
                        citydt.Rows.Add(2, 1, "Select");
                        citydt.Rows.Add(2, 2, "Isabela City (Capital)");
                        citydt.Rows.Add(2, 3, "Akbar");
                        citydt.Rows.Add(2, 4, "Al-Barka");
                        citydt.Rows.Add(2, 5, "Hadji Mohammad Ajul");
                        citydt.Rows.Add(2, 6, "Hadji Muhtamad");
                        citydt.Rows.Add(2, 7, "Lantawan");
                        citydt.Rows.Add(2, 8, "Maluso");
                        citydt.Rows.Add(2, 9, "Sumisip");
                        citydt.Rows.Add(2, 10, "Tabuan-Lasa");
                        citydt.Rows.Add(2, 11, "Tipo-Tipo");
                        citydt.Rows.Add(2, 12, "Tuburan");
                        citydt.Rows.Add(2, 13, "Ungkaya Pukan");
                    }
                    else if (province.SelectedValue == "3")
                    {
                        citydt.Rows.Add(3, 1, "Select");
                        citydt.Rows.Add(3, 2, "Marawi City (Capital)");
                        citydt.Rows.Add(3, 3, "Bacolod-Kalawi");
                        citydt.Rows.Add(3, 4, "Balabagan");
                        citydt.Rows.Add(3, 5, "Balindong (Watu)");
                        citydt.Rows.Add(3, 6, "Bayang");
                        citydt.Rows.Add(3, 7, "Binidayan");
                        citydt.Rows.Add(3, 8, "Buadiposo-Buntong");
                        citydt.Rows.Add(3, 9, "Bubong");
                        citydt.Rows.Add(3, 10, "Butig");
                        citydt.Rows.Add(3, 11, "Calanogas");
                        citydt.Rows.Add(3, 12, "Ditsaan-Ramain");
                        citydt.Rows.Add(3, 13, "Ganassi");
                        citydt.Rows.Add(3, 14, "Kapai");
                        citydt.Rows.Add(3, 15, "Kapatagan");
                        citydt.Rows.Add(3, 16, "Lumba-Bayabao (Maguing)");
                        citydt.Rows.Add(3, 17, "Lumbaca-Unayan");
                        citydt.Rows.Add(3, 18, "Lumbatan");
                        citydt.Rows.Add(3, 19, "Lumbayanague");
                        citydt.Rows.Add(3, 20, "Madalum");
                        citydt.Rows.Add(3, 21, "Madamba");
                        citydt.Rows.Add(3, 22, "Malabang");
                        citydt.Rows.Add(3, 23, "Marantao");
                        citydt.Rows.Add(3, 24, "Marogong");
                        citydt.Rows.Add(3, 25, "Masiu");
                        citydt.Rows.Add(3, 26, "Mulondo");
                        citydt.Rows.Add(3, 27, "Pagayawan");
                        citydt.Rows.Add(3, 28, "Piagapo");
                        citydt.Rows.Add(3, 29, "Picong (Sultan Gumander)");
                        citydt.Rows.Add(3, 30, "Poona Bayabao (Gata)");
                        citydt.Rows.Add(3, 31, "Pualas");
                        citydt.Rows.Add(3, 32, "Saguiaran");
                        citydt.Rows.Add(3, 33, "Sultan Dumalondong");
                        citydt.Rows.Add(3, 34, "Tagoloan II");
                        citydt.Rows.Add(3, 35, "Tamparan");
                        citydt.Rows.Add(3, 36, "Taraka");
                        citydt.Rows.Add(3, 37, "Tubaran");
                        citydt.Rows.Add(3, 38, "Tugaya");
                        citydt.Rows.Add(3, 39, "Wao");
                    }
                    else if (province.SelectedValue == "4")
                    {
                        citydt.Rows.Add(4, 1, "Select");
                        citydt.Rows.Add(4, 2, "Buluan (Capital)");
                        citydt.Rows.Add(4, 3, "Ampatuan");
                        citydt.Rows.Add(4, 4, "Barira");
                        citydt.Rows.Add(4, 5, "Buldon");
                        citydt.Rows.Add(4, 6, "Datu Abdullah Sangki");
                        citydt.Rows.Add(4, 7, "Datu Anggal Midtimbang");
                        citydt.Rows.Add(4, 8, "Datu Blah T. Sinsuat");
                        citydt.Rows.Add(4, 9, "Datu Hoffer Ampatuan");
                        citydt.Rows.Add(4, 10, "Datu Odin Sinsuat");
                        citydt.Rows.Add(4, 11, "Datu Paglas");
                        citydt.Rows.Add(4, 12, "Datu Piang");
                        citydt.Rows.Add(4, 13, "Datu Salibo");
                        citydt.Rows.Add(4, 14, "Datu Saudi-Ampatuan");
                        citydt.Rows.Add(4, 15, "Datu Unsay");
                        citydt.Rows.Add(4, 16, "General Salipada K. Pendatun");
                        citydt.Rows.Add(4, 17, "Guindulungan");
                        citydt.Rows.Add(4, 18, "Kabuntalan (Tumbao)");
                        citydt.Rows.Add(4, 19, "Mamasapano");
                        citydt.Rows.Add(4, 20, "Mangudadatu");
                        citydt.Rows.Add(4, 21, "Pagalungan");
                        citydt.Rows.Add(4, 22, "Paglat");
                        citydt.Rows.Add(4, 23, "Pandag");
                        citydt.Rows.Add(4, 24, "Parang");
                        citydt.Rows.Add(4, 25, "Rajah Buayan");
                        citydt.Rows.Add(4, 26, "Shariff Aguak (Maganoy)");
                        citydt.Rows.Add(4, 27, "Shariff Saydona Mustapha");
                        citydt.Rows.Add(4, 28, "South Upi");
                        citydt.Rows.Add(4, 29, "Sultan Kudarat");
                        citydt.Rows.Add(4, 30, "Sultan Mastura");
                        citydt.Rows.Add(4, 31, "Sultan sa Barongis (Lambayong)");
                        citydt.Rows.Add(4, 32, "Sultan Sumagka (Talitay)");
                        citydt.Rows.Add(4, 33, "Talayan");
                        citydt.Rows.Add(4, 34, "Talitay");
                        citydt.Rows.Add(4, 35, "Upi");
                    }
                    else if (province.SelectedValue == "5")
                    {
                        citydt.Rows.Add(5, 1, "Select");
                        citydt.Rows.Add(5, 2, "Jolo (Capital)");
                        citydt.Rows.Add(5, 3, "Indanan");
                        citydt.Rows.Add(5, 4, "Kalingalan Caluang");
                        citydt.Rows.Add(5, 5, "Lugus");
                        citydt.Rows.Add(5, 6, "Luuk");
                        citydt.Rows.Add(5, 7, "Maimbung");
                        citydt.Rows.Add(5, 8, "Old Panamao");
                        citydt.Rows.Add(5, 9, "Omar");
                        citydt.Rows.Add(5, 10, "Pandami");
                        citydt.Rows.Add(5, 11, "Panglima Estino (New Panamao)");
                        citydt.Rows.Add(5, 12, "Pangutaran");
                        citydt.Rows.Add(5, 13, "Parang");
                        citydt.Rows.Add(5, 14, "Pata");
                        citydt.Rows.Add(5, 15, "Patikul");
                        citydt.Rows.Add(5, 16, "Siasi");
                        citydt.Rows.Add(5, 17, "Talipao");
                        citydt.Rows.Add(5, 18, "Tapul");
                        citydt.Rows.Add(5, 19, "Tongkil");
                    }
                    else if (province.SelectedValue == "6")
                    {
                        citydt.Rows.Add(6, 1, "Select");
                        citydt.Rows.Add(6, 2, "Bongao (Capital)");
                        citydt.Rows.Add(6, 3, "Languyan");
                        citydt.Rows.Add(6, 4, "Mapun (Cagayan de Tawi-Tawi)");
                        citydt.Rows.Add(6, 5, "Panglima Sugala (Balimbing)");
                        citydt.Rows.Add(6, 6, "Sapa-Sapa");
                        citydt.Rows.Add(6, 7, "Sibutu");
                        citydt.Rows.Add(6, 8, "Simunul");
                        citydt.Rows.Add(6, 9, "Sitangkai");
                        citydt.Rows.Add(6, 10, "South Ubian");
                        citydt.Rows.Add(6, 11, "Tandubas");
                        citydt.Rows.Add(6, 12, "Turtle Islands (Taganak)");
                    }
                }

                city.DataSource = citydt;
                city.DataTextField = "CityName";
                city.DataValueField = "City ID";
                city.DataBind();
            }
        }

        private string GetValidationErrorMessage()
        {
            if (string.IsNullOrWhiteSpace(studentid.Text))
                return "Please enter the Student ID.";

            if (department.SelectedValue == "1")
                return "Please select the Department.";

            if (course.SelectedValue == "1")
                return "Please select the Course.";

            if (string.IsNullOrWhiteSpace(lastname.Text))
                return "Please enter the Last Name.";

            if (string.IsNullOrWhiteSpace(firstname.Text))
                return "Please enter the First Name.";

            if (string.IsNullOrWhiteSpace(middlename.Text))
                return "Please enter the Middle Name.";

            if (gender.SelectedValue == "")
                return "Please select the Gender.";

            if (civilstatus.SelectedValue == "1")
                return "Please select the Civil Status.";

            if (string.IsNullOrWhiteSpace(phone.Text))
                return "Please enter the Phone number.";

            if (string.IsNullOrWhiteSpace(email.Text))
                return "Please enter the Email Address.";

            if (region.SelectedValue == "1")
                return "Please select the Region.";

            if (province.SelectedValue == "1")
                return "Please select the Province.";

            if (city.SelectedValue == "1")
                return "Please select the City/Municipality.";

            if (string.IsNullOrWhiteSpace(barangay.Text))
                return "Please enter the Barangay.";

            if (string.IsNullOrWhiteSpace(street.Text))
                return "Please enter the Street.";

            if (string.IsNullOrWhiteSpace(zipcode.Text))
                return "Please enter the Zip Code.";

            return null;
        }

        protected void save_Click(object sender, EventArgs e)
        {
            DataTable coursedt = new DataTable();

            DataTable provincedt = new DataTable();

            DataTable citydt = new DataTable();

            string errorMessage = GetValidationErrorMessage();

            if (string.IsNullOrEmpty(errorMessage))
            {
                coursedt.Columns.Add("Department ID", typeof(int));
                coursedt.Columns.Add("Course ID", typeof(int));
                coursedt.Columns.Add("CourseName");

                provincedt.Columns.Add("Region ID", typeof(int));
                provincedt.Columns.Add("Province ID", typeof(int));
                provincedt.Columns.Add("ProvinceName");

                citydt.Columns.Add("Province ID", typeof(int));
                citydt.Columns.Add("City ID", typeof(int));
                citydt.Columns.Add("CityName");

                record.Visible = true;

                studentidlbl.Text = studentid.Text;
                departmentlbl.Text = department.SelectedItem.Text;
                courselbl.Text = course.SelectedItem.Text;
                name.Text = lastname.Text + ", " + firstname.Text + ", " + middlename.Text;
                genderlbl.Text = gender.Text;
                civilstatuslbl.Text = civilstatus.SelectedItem.Text;
                phonelbl.Text = phone.Text;
                emaillbl.Text = email.Text;
                address.Text = street.Text + ", " + barangay.Text + ", " + city.SelectedItem.Text + ", " + province.SelectedItem.Text + ", " + zipcode.Text;

                studentid.Text = "";
                department.ClearSelection();
                coursedt.Rows.Add(1, 1, "Select");
                lastname.Text = "";
                firstname.Text = "";
                middlename.Text = "";
                gender.ClearSelection();
                civilstatus.ClearSelection();
                phone.Text = "";
                email.Text = "";
                region.ClearSelection();
                provincedt.Rows.Add(1, 1, "Select");
                citydt.Rows.Add(1, 1, "Select");
                barangay.Text = "";
                street.Text = "";
                zipcode.Text = "";

                studentid.Enabled = false;
                department.Enabled = false;
                course.Enabled = false;
                lastname.Enabled = false;
                firstname.Enabled = false;
                middlename.Enabled = false;
                gender.Enabled = false;
                civilstatus.Enabled = false;
                phone.Enabled = false;
                email.Enabled = false;
                region.Enabled = false;
                province.Enabled = false;
                city.Enabled = false;
                barangay.Enabled = false;
                street.Enabled = false;
                zipcode.Enabled = false;

                course.DataSource = coursedt;
                course.DataTextField = "CourseName";
                course.DataValueField = "Course ID";
                course.DataBind();

                province.DataSource = provincedt;
                province.DataTextField = "ProvinceName";
                province.DataValueField = "Province ID";
                province.DataBind();

                city.DataSource = citydt;
                city.DataTextField = "CityName";
                city.DataValueField = "City ID";
                city.DataBind();

                ClientScript.RegisterStartupScript(this.GetType(), "alert", "Swal.fire({ position: 'center', icon: 'success', title: 'Your information has been printed', showConfirmButton: true});", true);

                save.Enabled = false;
                clear.Enabled = true;
            }
            else
            {
                studentid.Enabled = true;
                department.Enabled = true;
                course.Enabled = true;
                lastname.Enabled = true;
                firstname.Enabled = true;
                middlename.Enabled = true;
                gender.Enabled = true;
                civilstatus.Enabled = true;
                phone.Enabled = true;
                email.Enabled = true;
                region.Enabled = true;
                province.Enabled = true;
                city.Enabled = true;
                barangay.Enabled = true;
                street.Enabled = true;
                zipcode.Enabled = true;

                record.Visible = false;
                clear.Enabled = false;
                save.Enabled = true;

                ClientScript.RegisterStartupScript(this.GetType(), "alert", $"Swal.fire({{ icon: 'error', title: '{errorMessage}' }});", true);
            }
        }

        private void confirm()
        {
            studentid.Enabled = true;
            department.Enabled = true;
            course.Enabled = true;
            lastname.Enabled = true;
            firstname.Enabled = true;
            middlename.Enabled = true;
            gender.Enabled = true;
            civilstatus.Enabled = true;
            phone.Enabled = true;
            email.Enabled = true;
            region.Enabled = true;
            province.Enabled = true;
            city.Enabled = true;
            barangay.Enabled = true;
            street.Enabled = true;
            zipcode.Enabled = true;

            record.Visible = false;
            clear.Enabled = false;
            save.Enabled = true;
        }
    }
}